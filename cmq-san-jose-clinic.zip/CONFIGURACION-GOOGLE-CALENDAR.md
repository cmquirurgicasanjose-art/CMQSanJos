# 🔧 Configuración de Google Calendar API

## 📋 Pasos para configurar Google Calendar API

### 1. **Crear Proyecto en Google Cloud Console**

1. Ve a [Google Cloud Console](https://console.cloud.google.com/)
2. Inicia sesión con tu cuenta de Google de la clínica
3. Crea un nuevo proyecto:
   - Haz clic en "Seleccionar proyecto"
   - Haz clic en "Nuevo proyecto"
   - Nombre: "CMQ San José - Programación Quirúrgica"
   - Haz clic en "Crear"

### 2. **Habilitar Google Calendar API**

1. En el menú lateral, ve a "APIs y servicios" > "Biblioteca"
2. Busca "Google Calendar API"
3. Haz clic en "Google Calendar API"
4. Haz clic en "Habilitar"

### 3. **Crear Credenciales**

#### **API Key:**
1. Ve a "APIs y servicios" > "Credenciales"
2. Haz clic en "Crear credenciales" > "Clave de API"
3. Copia la API Key generada
4. (Opcional) Restringe la API Key para mayor seguridad

#### **OAuth 2.0 Client ID:**
1. En "Credenciales", haz clic en "Crear credenciales" > "ID de cliente OAuth 2.0"
2. Tipo de aplicación: "Aplicación web"
3. Nombre: "CMQ San José - Web App"
4. Orígenes JavaScript autorizados:
   - `http://localhost` (para desarrollo)
   - `https://tu-dominio.com` (para producción)
5. URIs de redirección autorizados:
   - `http://localhost` (para desarrollo)
   - `https://tu-dominio.com` (para producción)
6. Haz clic en "Crear"
7. Copia el Client ID generado

### 4. **Configurar la Aplicación**

1. Abre `web/surgical-scheduling-ui.html` en tu navegador
2. Deberías ver una alerta naranja en la esquina superior derecha
3. Haz clic en "Configurar Ahora"
4. Completa los campos:
   - **API Key**: Pega tu API Key
   - **Client ID**: Pega tu Client ID
   - **Calendar ID**: Deja "primary" (o especifica un calendario específico)
5. Haz clic en "Guardar Configuración"
6. Recarga la página

### 5. **Verificar Configuración**

1. Haz clic en "🔄 Sincronizar" en la aplicación
2. Deberías ver una ventana de autenticación de Google
3. Autoriza la aplicación
4. Verifica que aparezca "Sincronización completada"

## 🔒 Configuración de Seguridad (Recomendado)

### **Restringir API Key:**
1. Ve a "APIs y servicios" > "Credenciales"
2. Haz clic en tu API Key
3. En "Restricciones de aplicación":
   - Selecciona "Sitios web (HTTP)"
   - Agrega tus dominios autorizados
4. En "Restricciones de API":
   - Selecciona "Google Calendar API"

### **Configurar OAuth Consent Screen:**
1. Ve a "APIs y servicios" > "Pantalla de consentimiento de OAuth"
2. Tipo de usuario: "Externo"
3. Completa la información de la aplicación:
   - Nombre: "CMQ San José"
   - Email de soporte: tu email
   - Dominio autorizado: tu dominio
4. Agrega los alcances necesarios:
   - `https://www.googleapis.com/auth/calendar`
   - `https://www.googleapis.com/auth/calendar.events`

## 🚨 Solución de Problemas

### **Error: "API Key no válida"**
- Verifica que la API Key esté correctamente copiada
- Asegúrate de que Google Calendar API esté habilitada
- Verifica las restricciones de la API Key

### **Error: "Client ID no válido"**
- Verifica que el Client ID esté correctamente copiado
- Asegúrate de que el dominio esté en "Orígenes JavaScript autorizados"
- Verifica que OAuth Consent Screen esté configurado

### **Error: "Acceso denegado"**
- Verifica que el usuario tenga permisos en el calendario
- Asegúrate de que la aplicación esté autorizada
- Verifica que los alcances estén correctamente configurados

### **No aparece la alerta de configuración**
- Verifica que `google-calendar-config.js` esté cargado
- Abre la consola del navegador (F12) para ver errores
- Asegúrate de que todos los archivos estén en la misma carpeta

## 📞 Soporte

Si tienes problemas con la configuración:
1. Revisa la consola del navegador (F12) para errores
2. Verifica que todos los archivos estén cargados correctamente
3. Asegúrate de que las credenciales estén correctamente configuradas

## 🔄 Actualización de Configuración

Para cambiar la configuración:
1. Abre la consola del navegador (F12)
2. Ejecuta: `localStorage.removeItem('googleCalendarConfig')`
3. Recarga la página
4. La alerta de configuración debería aparecer nuevamente

