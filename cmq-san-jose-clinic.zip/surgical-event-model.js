// Modelo de datos para eventos quirúrgicos
class SurgicalEvent {
    constructor(data = {}) {
        this.id = data.id || this.generateId();
        this.title = data.title || '';
        this.patientId = data.patientId || '';
        this.patientName = data.patientName || '';
        this.patientDiagnosis = data.patientDiagnosis || '';
        this.roomId = data.roomId || '';
        this.roomNumber = data.roomNumber || '';
        this.startDateTime = data.startDateTime || '';
        this.endDateTime = data.endDateTime || '';
        this.specialty = data.specialty || '';
        this.procedure = data.procedure || '';
        this.medicalTeam = data.medicalTeam || {
            treatingDoctor: '',
            surgeon: '',
            assistant: '',
            anesthesiologist: '',
            instrumentNurse: '',
            circulatingNurse: '',
            scrubNurse: ''
        };
        this.priority = data.priority || 'NORMAL'; // URGENTE, ALTA, NORMAL, BAJA
        this.status = data.status || 'PROGRAMADA'; // PROGRAMADA, EN_CURSO, COMPLETADA, CANCELADA, POSTPUESTA
        this.notes = data.notes || '';
        this.preoperativeNotes = data.preoperativeNotes || '';
        this.postoperativeNotes = data.postoperativeNotes || '';
        this.estimatedDuration = data.estimatedDuration || 120; // en minutos
        this.actualDuration = data.actualDuration || 0; // en minutos
        this.googleCalendarEventId = data.googleCalendarEventId || '';
        this.notifications = data.notifications || {
            googleCalendar: true,
            pushNotification: true,
            emailNotification: false,
            smsNotification: false
        };
        this.createdAt = data.createdAt || new Date().toISOString();
        this.updatedAt = data.updatedAt || new Date().toISOString();
        this.createdBy = data.createdBy || '';
        this.updatedBy = data.updatedBy || '';
    }

    generateId() {
        return 'surgery_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    // Validar datos del evento
    validate() {
        const errors = [];
        
        if (!this.title.trim()) {
            errors.push('El título es requerido');
        }
        
        if (!this.patientName.trim()) {
            errors.push('El nombre del paciente es requerido');
        }
        
        if (!this.startDateTime) {
            errors.push('La fecha y hora de inicio es requerida');
        }
        
        if (!this.endDateTime) {
            errors.push('La fecha y hora de fin es requerida');
        }
        
        if (new Date(this.startDateTime) >= new Date(this.endDateTime)) {
            errors.push('La fecha de fin debe ser posterior a la fecha de inicio');
        }
        
        if (!this.specialty) {
            errors.push('La especialidad es requerida');
        }
        
        if (!this.procedure.trim()) {
            errors.push('El procedimiento es requerido');
        }
        
        if (!this.medicalTeam.surgeon.trim()) {
            errors.push('El cirujano es requerido');
        }
        
        return errors;
    }

    // Convertir a objeto para Firebase
    toFirebaseObject() {
        return {
            id: this.id,
            title: this.title,
            patientId: this.patientId,
            patientName: this.patientName,
            patientDiagnosis: this.patientDiagnosis,
            roomId: this.roomId,
            roomNumber: this.roomNumber,
            startDateTime: this.startDateTime,
            endDateTime: this.endDateTime,
            specialty: this.specialty,
            procedure: this.procedure,
            medicalTeam: this.medicalTeam,
            priority: this.priority,
            status: this.status,
            notes: this.notes,
            preoperativeNotes: this.preoperativeNotes,
            postoperativeNotes: this.postoperativeNotes,
            estimatedDuration: this.estimatedDuration,
            actualDuration: this.actualDuration,
            googleCalendarEventId: this.googleCalendarEventId,
            notifications: this.notifications,
            createdAt: this.createdAt,
            updatedAt: this.updatedAt,
            createdBy: this.createdBy,
            updatedBy: this.updatedBy
        };
    }

    // Crear desde objeto de Firebase
    static fromFirebaseObject(data) {
        return new SurgicalEvent(data);
    }

    // Calcular duración estimada
    calculateEstimatedDuration() {
        if (this.startDateTime && this.endDateTime) {
            const start = new Date(this.startDateTime);
            const end = new Date(this.endDateTime);
            this.estimatedDuration = Math.round((end - start) / (1000 * 60)); // en minutos
        }
        return this.estimatedDuration;
    }

    // Verificar si el evento está en curso
    isInProgress() {
        const now = new Date();
        const start = new Date(this.startDateTime);
        const end = new Date(this.endDateTime);
        return now >= start && now <= end;
    }

    // Verificar si el evento está próximo
    isUpcoming(minutes = 30) {
        const now = new Date();
        const start = new Date(this.startDateTime);
        const timeDiff = start - now;
        return timeDiff > 0 && timeDiff <= (minutes * 60 * 1000);
    }

    // Obtener estado del evento
    getStatus() {
        const now = new Date();
        const start = new Date(this.startDateTime);
        const end = new Date(this.endDateTime);
        
        if (this.status === 'CANCELADA' || this.status === 'POSTPUESTA') {
            return this.status;
        }
        
        if (now < start) {
            return 'PROGRAMADA';
        } else if (now >= start && now <= end) {
            return 'EN_CURSO';
        } else {
            return 'COMPLETADA';
        }
    }

    // Actualizar estado automáticamente
    updateStatus() {
        this.status = this.getStatus();
        this.updatedAt = new Date().toISOString();
    }
}

// Clase para manejar el equipo médico
class MedicalTeam {
    constructor(data = {}) {
        this.treatingDoctor = data.treatingDoctor || '';
        this.surgeon = data.surgeon || '';
        this.assistant = data.assistant || '';
        this.anesthesiologist = data.anesthesiologist || '';
        this.instrumentNurse = data.instrumentNurse || '';
        this.circulatingNurse = data.circulatingNurse || '';
        this.scrubNurse = data.scrubNurse || '';
    }

    // Validar equipo médico
    validate() {
        const errors = [];
        
        if (!this.surgeon.trim()) {
            errors.push('El cirujano es requerido');
        }
        
        if (!this.anesthesiologist.trim()) {
            errors.push('El anestesiólogo es requerido');
        }
        
        if (!this.instrumentNurse.trim()) {
            errors.push('La enfermera instrumentista es requerida');
        }
        
        return errors;
    }

    // Obtener lista de miembros del equipo
    getTeamMembers() {
        const members = [];
        
        if (this.treatingDoctor) members.push({ role: 'Médico Tratante', name: this.treatingDoctor });
        if (this.surgeon) members.push({ role: 'Cirujano', name: this.surgeon });
        if (this.assistant) members.push({ role: 'Ayudante', name: this.assistant });
        if (this.anesthesiologist) members.push({ role: 'Anestesiólogo', name: this.anesthesiologist });
        if (this.instrumentNurse) members.push({ role: 'Enfermera Instrumentista', name: this.instrumentNurse });
        if (this.circulatingNurse) members.push({ role: 'Enfermera Circulante', name: this.circulatingNurse });
        if (this.scrubNurse) members.push({ role: 'Enfermera de Campo', name: this.scrubNurse });
        
        return members;
    }
}

// Exportar clases
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { SurgicalEvent, MedicalTeam };
}
