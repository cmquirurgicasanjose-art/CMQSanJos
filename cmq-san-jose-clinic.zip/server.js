const http = require('http');
const fs = require('fs');
const path = require('path');

const port = 8000;

// MIME types para diferentes extensiones de archivo
const mimeTypes = {
    '.html': 'text/html',
    '.js': 'text/javascript',
    '.css': 'text/css',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.wav': 'audio/wav',
    '.mp4': 'video/mp4',
    '.woff': 'application/font-woff',
    '.ttf': 'application/font-ttf',
    '.eot': 'application/vnd.ms-fontobject',
    '.otf': 'application/font-otf',
    '.wasm': 'application/wasm'
};

const server = http.createServer((req, res) => {
    console.log(`${req.method} ${req.url}`);

    // Parsear la URL
    let filePath = '.' + req.url;
    if (filePath === './') {
        filePath = './index.html';
    }

    // Obtener la extensión del archivo
    const extname = String(path.extname(filePath)).toLowerCase();
    const mimeType = mimeTypes[extname] || 'application/octet-stream';

    // Leer el archivo
    fs.readFile(filePath, (error, content) => {
        if (error) {
            if (error.code === 'ENOENT') {
                res.writeHead(404, { 'Content-Type': 'text/html' });
                res.end(`
                    <html>
                        <head><title>404 - Archivo no encontrado</title></head>
                        <body>
                            <h1>404 - Archivo no encontrado</h1>
                            <p>El archivo <code>${req.url}</code> no existe.</p>
                            <p>Archivos disponibles:</p>
                            <ul>
                                <li><a href="/index.html">index.html</a></li>
                                <li><a href="/index-hybrid-realtime.html">index-hybrid-realtime.html</a></li>
                                <li><a href="/surgical-scheduling-ui.html">surgical-scheduling-ui.html</a></li>
                            </ul>
                        </body>
                    </html>
                `);
            } else {
                res.writeHead(500);
                res.end(`Error del servidor: ${error.code}`);
            }
        } else {
            res.writeHead(200, { 'Content-Type': mimeType });
            res.end(content, 'utf-8');
        }
    });
});

server.listen(port, () => {
    console.log(`🚀 Servidor ejecutándose en http://localhost:${port}`);
    console.log(`📁 Sirviendo archivos desde: ${__dirname}`);
    console.log(`📋 Archivos disponibles:`);
    console.log(`   - http://localhost:${port}/index.html`);
    console.log(`   - http://localhost:${port}/index-hybrid-realtime.html`);
    console.log(`   - http://localhost:${port}/surgical-scheduling-ui.html`);
});
