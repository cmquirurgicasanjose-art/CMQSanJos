// Configuración de Google Calendar API
// IMPORTANTE: Reemplaza estos valores con tus credenciales reales

const GOOGLE_CALENDAR_CONFIG = {
    // Tu API Key de Google Cloud Console
    apiKey: 'TU_API_KEY_AQUI',
    
    // Tu Client ID de Google Cloud Console
    clientId: 'TU_CLIENT_ID_AQUI.apps.googleusercontent.com',
    
    // ID del calendario de la clínica (opcional, por defecto usa 'primary')
    calendarId: 'primary',
    
    // Scopes necesarios para la aplicación
    scopes: [
        'https://www.googleapis.com/auth/calendar',
        'https://www.googleapis.com/auth/calendar.events'
    ],
    
    // Configuración de notificaciones
    notifications: {
        // Tiempo en minutos antes del evento para notificar
        reminderTimes: [30, 60, 1440], // 30 min, 1 hora, 24 horas
        
        // Métodos de notificación
        methods: ['popup', 'email']
    },
    
    // Configuración de la zona horaria
    timeZone: 'America/Mexico_City',
    
    // Configuración de desarrollo
    development: {
        // URL base para desarrollo
        baseUrl: 'http://localhost:8000',
        // Habilitar logs de depuración
        debug: true
    },
    
    // Configuración de colores para diferentes prioridades
    priorityColors: {
        'URGENTE': '11',    // Rojo
        'ALTA': '6',        // Naranja
        'NORMAL': '10',     // Verde
        'BAJA': '5'         // Amarillo
    }
};

// Función para verificar si la configuración está completa
function isGoogleCalendarConfigured() {
    return GOOGLE_CALENDAR_CONFIG.apiKey !== 'TU_API_KEY_AQUI' && 
           GOOGLE_CALENDAR_CONFIG.clientId !== 'TU_CLIENT_ID_AQUI.apps.googleusercontent.com';
}

// Función para mostrar alerta de configuración
function showConfigurationAlert() {
    const alertDiv = document.createElement('div');
    alertDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #f39c12;
        color: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        z-index: 10000;
        max-width: 400px;
        font-family: Arial, sans-serif;
    `;
    
    alertDiv.innerHTML = `
        <h3 style="margin: 0 0 10px 0;">⚠️ Configuración Requerida</h3>
        <p style="margin: 0 0 15px 0;">Para usar Google Calendar, necesitas configurar las credenciales de API.</p>
        <button onclick="showConfigurationModal()" style="
            background: #2c3e50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
        ">Configurar Ahora</button>
        <button onclick="this.parentElement.remove()" style="
            background: transparent;
            color: white;
            border: 1px solid white;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            margin-left: 10px;
        ">Cerrar</button>
    `;
    
    document.body.appendChild(alertDiv);
}

// Función para mostrar modal de configuración
function showConfigurationModal() {
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.8);
        z-index: 10001;
        display: flex;
        justify-content: center;
        align-items: center;
    `;
    
    modal.innerHTML = `
        <div style="
            background: white;
            padding: 30px;
            border-radius: 15px;
            max-width: 600px;
            max-height: 80vh;
            overflow-y: auto;
            font-family: Arial, sans-serif;
        ">
            <h2 style="color: #2c3e50; margin-bottom: 20px;">🔧 Configuración de Google Calendar API</h2>
            
            <div style="margin-bottom: 20px;">
                <h3>📋 Pasos para configurar:</h3>
                <ol style="line-height: 1.6;">
                    <li>Ve a <a href="https://console.cloud.google.com/" target="_blank">Google Cloud Console</a></li>
                    <li>Crea un nuevo proyecto o selecciona uno existente</li>
                    <li>Habilita la Google Calendar API</li>
                    <li>Crea credenciales (API Key y OAuth 2.0 Client ID)</li>
                    <li>Configura los dominios autorizados</li>
                </ol>
            </div>
            
            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 5px; font-weight: bold;">API Key:</label>
                <input type="text" id="apiKeyInput" placeholder="Tu API Key aquí" style="
                    width: 100%;
                    padding: 10px;
                    border: 2px solid #ddd;
                    border-radius: 5px;
                    font-size: 14px;
                ">
            </div>
            
            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 5px; font-weight: bold;">Client ID:</label>
                <input type="text" id="clientIdInput" placeholder="Tu Client ID aquí" style="
                    width: 100%;
                    padding: 10px;
                    border: 2px solid #ddd;
                    border-radius: 5px;
                    font-size: 14px;
                ">
            </div>
            
            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 5px; font-weight: bold;">Calendar ID (opcional):</label>
                <input type="text" id="calendarIdInput" placeholder="primary" style="
                    width: 100%;
                    padding: 10px;
                    border: 2px solid #ddd;
                    border-radius: 5px;
                    font-size: 14px;
                ">
            </div>
            
            <div style="text-align: right;">
                <button onclick="saveConfiguration()" style="
                    background: #27ae60;
                    color: white;
                    border: none;
                    padding: 12px 24px;
                    border-radius: 5px;
                    cursor: pointer;
                    font-weight: bold;
                    margin-right: 10px;
                ">💾 Guardar Configuración</button>
                <button onclick="this.closest('div').parentElement.remove()" style="
                    background: #95a5a6;
                    color: white;
                    border: none;
                    padding: 12px 24px;
                    border-radius: 5px;
                    cursor: pointer;
                ">Cancelar</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

// Función para guardar configuración
function saveConfiguration() {
    const apiKey = document.getElementById('apiKeyInput').value;
    const clientId = document.getElementById('clientIdInput').value;
    const calendarId = document.getElementById('calendarIdInput').value || 'primary';
    
    if (!apiKey || !clientId) {
        alert('Por favor, completa todos los campos requeridos.');
        return;
    }
    
    // Actualizar configuración
    GOOGLE_CALENDAR_CONFIG.apiKey = apiKey;
    GOOGLE_CALENDAR_CONFIG.clientId = clientId;
    GOOGLE_CALENDAR_CONFIG.calendarId = calendarId;
    
    // Guardar en localStorage
    localStorage.setItem('googleCalendarConfig', JSON.stringify(GOOGLE_CALENDAR_CONFIG));
    
    // Cerrar modal
    document.querySelector('[style*="position: fixed"]').remove();
    
    // Mostrar mensaje de éxito
    alert('✅ Configuración guardada correctamente. Recarga la página para aplicar los cambios.');
    
    // Recargar página
    window.location.reload();
}

// Función para cargar configuración desde localStorage
function loadConfiguration() {
    const savedConfig = localStorage.getItem('googleCalendarConfig');
    if (savedConfig) {
        const config = JSON.parse(savedConfig);
        Object.assign(GOOGLE_CALENDAR_CONFIG, config);
    }
}

// Función para obtener configuración
function getGoogleCalendarConfig() {
    return GOOGLE_CALENDAR_CONFIG;
}

// Cargar configuración al inicializar
loadConfiguration();

// Exportar configuración
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { GOOGLE_CALENDAR_CONFIG, getGoogleCalendarConfig, isGoogleCalendarConfigured };
}
