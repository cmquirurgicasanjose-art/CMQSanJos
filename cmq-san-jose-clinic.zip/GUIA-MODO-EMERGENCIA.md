# 🚨 Guía de Uso: Modo Emergencia

## 🎯 **¿Qué es el Modo Emergencia?**

El **Modo Emergencia** es una versión simplificada de la aplicación que funciona **siempre** que tengas conexión a internet. No depende de Firestore, por lo que evita el problema de "client is offline".

## 🚀 **Cómo Acceder**

### **Opción 1: Desde la página principal**
1. **Ve a la página de login**
2. **Haz clic en "🚨 Modo Emergencia"** (botón naranja)
3. **¡Listo!** Ya estás en el modo emergencia

### **Opción 2: Acceso directo**
1. **Ve directamente a:** `index-auth-only.html`
2. **Haz login normalmente**

## ✅ **Funcionalidades Disponibles**

### **🔐 Autenticación**
- ✅ **Login** con email y contraseña
- ✅ **Crear nuevos usuarios** con roles
- ✅ **Cerrar sesión**
- ✅ **Información del usuario**

### **👤 Gestión de Usuarios**
- ✅ **Crear usuarios** con roles:
  - 👑 **ADMINISTRADOR** (control total)
  - 👨‍⚕️ **MEDICO** (acceso médico)
  - 👩‍⚕️ **ENFERMERA** (acceso enfermería)

### **📋 Menú de Opciones**
- 🏠 **Gestión de Cuartos** (información)
- 👥 **Gestión de Pacientes** (información)
- 🏥 **Programación Quirúrgica** (información)
- 👤 **Gestión de Usuarios** (información)

## 🛠️ **Cómo Usar**

### **1. Hacer Login**
1. **Ingresa tu email y contraseña**
2. **Haz clic en "Iniciar Sesión"**
3. **¡Acceso exitoso!**

### **2. Crear un Nuevo Usuario**
1. **Haz clic en "➕ Crear Usuario"**
2. **Ingresa los datos:**
   - 👤 **Nombre** del usuario
   - 📧 **Email** del usuario
   - 🔒 **Contraseña** (mínimo 6 caracteres)
   - 👔 **Rol** (1=Admin, 2=Médico, 3=Enfermera)
3. **¡Usuario creado!**

### **3. Explorar Funcionalidades**
1. **Haz clic en cualquier botón del menú**
2. **Verás información** sobre esa funcionalidad
3. **Para funcionalidad completa:** usa "🔄 Versión Completa"

## 🔄 **Navegación**

### **Volver a la Versión Completa**
1. **Haz clic en "🔄 Versión Completa"**
2. **Te lleva a la página principal**
3. **Puedes intentar usar** la versión completa

### **Cerrar Sesión**
1. **Haz clic en "🚪 Cerrar Sesión"**
2. **Vuelves a la pantalla de login**
3. **Puedes hacer login** con otro usuario

## 📱 **Comparación de Versiones**

| Característica | Modo Emergencia | Versión Completa |
|---|---|---|
| **Autenticación** | ✅ Siempre funciona | ✅ Funciona |
| **Crear Usuarios** | ✅ Siempre funciona | ✅ Funciona |
| **Gestión de Cuartos** | ❌ Solo información | ✅ Completa |
| **Gestión de Pacientes** | ❌ Solo información | ✅ Completa |
| **Programación Quirúrgica** | ❌ Solo información | ✅ Completa |
| **Conectividad** | ✅ Solo internet | ❌ Depende de Firestore |
| **Confiabilidad** | ✅ 100% confiable | ⚠️ Puede fallar |

## 🎯 **Cuándo Usar Cada Versión**

### **Usa Modo Emergencia cuando:**
- ❌ **La versión completa no funciona**
- ❌ **Aparece error "client is offline"**
- ❌ **Firestore tiene problemas**
- ✅ **Necesitas acceso básico** al sistema
- ✅ **Quieres crear usuarios** rápidamente

### **Usa Versión Completa cuando:**
- ✅ **Todo funciona correctamente**
- ✅ **Necesitas gestión completa** de cuartos
- ✅ **Necesitas gestión completa** de pacientes
- ✅ **Necesitas programación quirúrgica**

## 🚀 **Ventajas del Modo Emergencia**

1. **🔒 Confiabilidad:** Siempre funciona con internet
2. **⚡ Velocidad:** Carga más rápido
3. **🛠️ Simplicidad:** Interfaz más simple
4. **👤 Gestión de usuarios:** Crear usuarios fácilmente
5. **🔄 Acceso rápido:** No depende de Firestore

## 💡 **Consejos de Uso**

1. **Guarda el enlace** a `index-auth-only.html` como favorito
2. **Usa para crear usuarios** cuando la versión completa falle
3. **Acceso de emergencia** cuando hay problemas técnicos
4. **Prueba la versión completa** periódicamente
5. **Usa la app Android** para funcionalidad completa

## 🔧 **Solución de Problemas**

### **Si no puedes hacer login:**
1. **Verifica tu email y contraseña**
2. **Asegúrate de tener internet**
3. **Recarga la página**
4. **Intenta crear un nuevo usuario**

### **Si no puedes crear usuarios:**
1. **Verifica que tengas internet**
2. **Asegúrate de usar contraseña de 6+ caracteres**
3. **Verifica que el email no esté en uso**
4. **Recarga la página**

### **Si quieres funcionalidad completa:**
1. **Haz clic en "🔄 Versión Completa"**
2. **O usa la app Android**
3. **O espera a que se solucione** el problema de Firestore

## ✅ **Confirmación de Funcionamiento**

**El Modo Emergencia está funcionando correctamente si:**
- ✅ **Puedes hacer login** sin errores
- ✅ **Ves el dashboard** con tu información
- ✅ **Puedes crear usuarios** exitosamente
- ✅ **Los botones del menú** responden
- ✅ **Puedes cerrar sesión** y volver a hacer login

## 🎉 **¡Listo para Usar!**

El **Modo Emergencia** te permite:
- 🔐 **Acceder al sistema** cuando hay problemas
- 👤 **Crear usuarios** para tu equipo
- 📋 **Ver información** sobre funcionalidades
- 🔄 **Volver a la versión completa** cuando funcione

**¡Es tu solución de respaldo confiable! 🚀**

