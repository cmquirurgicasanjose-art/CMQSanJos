# 🚨 Error "unavailable" - Solución Completa

## 🔍 **¿Qué significa el error "unavailable"?**

El error `auth/unavailable` indica que **Firebase Authentication no está disponible**. Esto puede ser por:

1. **Problemas de conectividad** con los servidores de Firebase
2. **Configuración incorrecta** de Firebase
3. **Problemas de red** o firewall
4. **Servicios de Firebase temporalmente fuera de servicio**

## 🛠️ **Soluciones paso a paso:**

### **Paso 1: Verificar conectividad básica**

1. **Abre la página web**
2. **Presiona F12** para abrir la consola
3. **Haz clic en "🔍 Probar Conexión"**
4. **Mira los mensajes en la consola:**
   - ✅ `Conexión con Firestore exitosa` = Todo bien
   - ❌ `Error de conexión con Firestore` = Problema de red

### **Paso 2: Verificar configuración de Firebase**

1. **Abre `web/firebase-config.js`**
2. **Verifica que la configuración sea correcta:**
   ```javascript
   const firebaseConfig = {
       apiKey: "AIzaSyACgsmCsd2r5KnwfQSlZlt20-YrpZbwJIw",
       authDomain: "cmqsanjos-clinica.firebaseapp.com",
       projectId: "cmqsanjos-clinica",
       // ... resto de la configuración
   };
   ```

### **Paso 3: Verificar en Firebase Console**

1. **Ve a [Firebase Console](https://console.firebase.google.com/)**
2. **Selecciona tu proyecto "CMQ San José"**
3. **Ve a Authentication > Settings**
4. **Verifica que esté habilitado:**
   - ✅ Email/Password authentication
   - ✅ El dominio esté autorizado

### **Paso 4: Verificar reglas de Firestore**

1. **En Firebase Console > Firestore Database > Rules**
2. **Verifica que las reglas permitan autenticación:**
   ```javascript
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /users/{userId} {
         allow read, write: if request.auth != null && request.auth.uid == userId;
       }
     }
   }
   ```

### **Paso 5: Probar desde diferentes redes**

1. **Prueba desde tu red WiFi**
2. **Prueba desde datos móviles**
3. **Prueba desde otra red (casa de un amigo)**

### **Paso 6: Verificar firewall/proxy**

Si estás en una red corporativa o con firewall:

1. **Verifica que estos dominios estén permitidos:**
   - `firebaseapp.com`
   - `googleapis.com`
   - `gstatic.com`

2. **Contacta al administrador de red** si es necesario

## 🔧 **Soluciones técnicas:**

### **Solución 1: Recargar la página**
```javascript
// En la consola del navegador
location.reload();
```

### **Solución 2: Limpiar todo el caché**
1. **Presiona Ctrl+Shift+Delete**
2. **Selecciona "Todo"**
3. **Haz clic en "Limpiar datos"**

### **Solución 3: Probar en modo incógnito**
1. **Abre una ventana incógnita**
2. **Ve a la página web**
3. **Intenta hacer login**

### **Solución 4: Verificar DNS**
1. **Cambia tu DNS a:**
   - **Primario**: 8.8.8.8
   - **Secundario**: 8.8.4.4

## 📱 **Verificar desde la app Android:**

1. **Abre la app Android**
2. **Intenta hacer login**
3. **Si funciona en Android pero no en web:**
   - Problema específico del navegador
   - Usar modo incógnito o limpiar caché

## 🌐 **Verificar estado de Firebase:**

1. **Ve a [Firebase Status](https://status.firebase.google.com/)**
2. **Verifica si hay problemas reportados**
3. **Si hay problemas, espera a que se resuelvan**

## 🆘 **Si nada funciona:**

### **Opción 1: Crear nuevo usuario**
1. **Haz clic en "Crear Nueva Cuenta"**
2. **Crea un usuario de prueba**
3. **Intenta hacer login con el nuevo usuario**

### **Opción 2: Verificar desde otro dispositivo**
1. **Usa otro computador/tablet**
2. **Abre la página web**
3. **Intenta hacer login**

### **Opción 3: Contactar soporte**
Si el problema persiste, incluye esta información:
- **Navegador** y versión
- **Sistema operativo**
- **Mensajes de la consola**
- **Si funciona en Android** o no
- **Tipo de conexión** (WiFi, datos móviles, etc.)

## ✅ **Verificación final:**

Para confirmar que está solucionado:
1. ✅ **"🔍 Probar Conexión"** muestra éxito
2. ✅ **Login funciona** sin errores
3. ✅ **No hay errores** en la consola
4. ✅ **Funciona en Android** también

## 🔄 **Comandos de diagnóstico:**

Ejecuta estos en la consola del navegador:

```javascript
// Verificar Firebase
console.log('Auth:', auth);
console.log('DB:', db);

// Verificar conectividad
navigator.onLine;

// Probar conexión
testFirebaseConnection();
```

