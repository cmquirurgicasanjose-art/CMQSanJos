// Configuración de Firebase para la aplicación web
// IMPORTANTE: Reemplaza estos valores con tu configuración real de Firebase

const firebaseConfig = {
    apiKey: "AIzaSyACgsmCsd2r5KnwfQSlZlt20-YrpZbwJIw",
    authDomain: "cmqsanjos-clinica.firebaseapp.com",
    projectId: "cmqsanjos-clinica",
    storageBucket: "cmqsanjos-clinica.firebasestorage.app",
    messagingSenderId: "403556686078",
    appId: "1:403556686078:web:75b193e2e057b890806daf",
    measurementId: "G-CE0ZYRJT9F"
  };
  
// Variable global para almacenar la instancia de Firebase
window.firebaseApp = null;

// Función para inicializar Firebase
function initializeFirebase() {
    if (typeof firebase !== 'undefined') {
        try {
            // Verificar si ya está inicializado
            if (firebase.apps && firebase.apps.length > 0) {
                console.log('✅ Firebase ya está inicializado');
                window.firebaseApp = firebase.apps[0];
                return { auth: firebase.auth(), database: firebase.database() };
            }
            
            const app = firebase.initializeApp(firebaseConfig);
            const auth = firebase.auth();
            const database = firebase.database();
            
            // Guardar la instancia globalmente
            window.firebaseApp = app;
            
            console.log('✅ Firebase inicializado correctamente con Realtime Database');
            return { auth, database };
        } catch (error) {
            console.error('❌ Error al inicializar Firebase:', error);
            return null;
        }
    } else {
        console.error('❌ Firebase SDK no está cargado');
        return null;
    }
}

// Inicializar Firebase inmediatamente cuando se carga el script
console.log('🔄 Iniciando Firebase...');
const result = initializeFirebase();
if (result) {
    console.log('✅ Firebase inicializado exitosamente');
} else {
    console.error('❌ Error al inicializar Firebase');
}

// Función para obtener mensajes de error en español
function getFirebaseErrorMessage(errorCode) {
    const errorMessages = {
        'auth/user-not-found': 'No existe una cuenta con este correo electrónico',
        'auth/wrong-password': 'Contraseña incorrecta. Verifica tu contraseña o reiníciala desde la app',
        'auth/email-already-in-use': 'Ya existe una cuenta con este correo electrónico',
        'auth/weak-password': 'La contraseña debe tener al menos 6 caracteres',
        'auth/invalid-email': 'Correo electrónico inválido',
        'auth/too-many-requests': 'Demasiados intentos fallidos. Intenta más tarde',
        'auth/network-request-failed': 'Error de conexión. Verifica tu internet',
        'auth/operation-not-allowed': 'Operación no permitida',
        'auth/requires-recent-login': 'Por seguridad, inicia sesión nuevamente',
        'auth/invalid-credential': 'Credenciales inválidas. Verifica tu email y contraseña',
        'auth/user-disabled': 'Esta cuenta ha sido deshabilitada',
        'auth/account-exists-with-different-credential': 'Ya existe una cuenta con este email pero con diferente método de autenticación',
        'auth/credential-already-in-use': 'Esta credencial ya está en uso',
        'auth/invalid-verification-code': 'Código de verificación inválido',
        'auth/invalid-verification-id': 'ID de verificación inválido',
        'auth/missing-verification-code': 'Código de verificación faltante',
        'auth/missing-verification-id': 'ID de verificación faltante',
        'auth/quota-exceeded': 'Se ha excedido la cuota de solicitudes',
        'auth/timeout': 'Tiempo de espera agotado. Intenta nuevamente',
        'auth/unavailable': 'Servicio de autenticación no disponible. Verifica tu conexión a internet',
        'auth/service-unavailable': 'Servicio temporalmente no disponible. Intenta más tarde'
    };
    
    console.log('Error de Firebase:', errorCode); // Para debugging
    return errorMessages[errorCode] || `Error de autenticación: ${errorCode}. Intenta nuevamente`;
}
