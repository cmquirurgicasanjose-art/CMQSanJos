# 🧪 Guía de Test - Google Calendar API

## 🚀 **Solución Rápida (Sin Servidor)**

Como Python no está disponible en tu sistema, hemos creado una página de test que funciona directamente desde el navegador.

### **📋 Pasos para Probar:**

#### **1. Abrir la Página de Test**
- **Navega a la carpeta** `web` en tu proyecto
- **Haz doble clic** en `test-google-calendar.html`
- Se abrirá en tu navegador

#### **2. Configurar Credenciales**
- **Ingresa tu API Key** en el primer campo
- **Ingresa tu Client ID** en el segundo campo
- **Haz clic en "💾 Guardar Configuración"**

#### **3. Probar la Integración**
1. **🔄 Inicializar API** - Carga la API de Google Calendar
2. **🔐 Autenticar** - Inicia sesión con tu cuenta de Google
3. **📅 Probar Acceso a Calendar** - Verifica que puede acceder a tus calendarios
4. **➕ Crear Evento de Prueba** - Crea un evento de prueba

### **⚠️ Importante: Configurar Google Cloud Console**

Antes de probar, asegúrate de que en Google Cloud Console:

1. **Ve a "APIs y servicios" > "Credenciales"**
2. **Haz clic en tu Client ID**
3. **En "Orígenes JavaScript autorizados"**, agrega:
   - `file://`
   - `http://localhost:8000`
   - `http://127.0.0.1:8000`
4. **Guarda los cambios**

### **🔧 Solución Alternativa: Usar Live Server**

Si tienes **VS Code** instalado:

1. **Instala la extensión** "Live Server"
2. **Haz clic derecho** en `test-google-calendar.html`
3. **Selecciona** "Open with Live Server"
4. **Sigue los pasos de configuración**

### **📊 Interpretación de Resultados**

#### **✅ Éxito:**
- **Verde**: Todo funciona correctamente
- **API inicializada**: Google Calendar API cargada
- **Autenticado**: Sesión iniciada correctamente
- **Acceso a Calendar**: Puede leer tus calendarios
- **Evento creado**: Se creó un evento de prueba

#### **❌ Errores Comunes:**
- **"Configuración incompleta"**: Ingresa API Key y Client ID
- **"API no inicializada"**: Haz clic en "Inicializar API" primero
- **"No autenticado"**: Haz clic en "Autenticar" primero
- **"Error de autenticación"**: Verifica las credenciales en Google Cloud Console

### **🎯 Próximos Pasos**

Una vez que el test funcione correctamente:

1. **Actualiza Google Cloud Console** con los orígenes correctos
2. **Usa la página principal** `surgical-scheduling-ui.html`
3. **Configura las credenciales** en la aplicación principal
4. **Prueba la sincronización** completa

### **🆘 Si Necesitas Ayuda**

Si encuentras errores:
1. **Copia el mensaje de error** completo
2. **Verifica las credenciales** en Google Cloud Console
3. **Asegúrate de que la API esté habilitada**
4. **Revisa que los orígenes estén configurados**

---

**💡 Tip**: Esta página de test te permite verificar que todo funciona antes de usar la aplicación principal.

