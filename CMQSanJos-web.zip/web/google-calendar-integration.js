// Integración con Google Calendar API para cirugías
class GoogleCalendarIntegration {
    constructor() {
        this.config = getGoogleCalendarConfig();
        this.apiKey = this.config.apiKey;
        this.clientId = this.config.clientId;
        this.discoveryDoc = 'https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest';
        this.scopes = this.config.scopes.join(' ');
        this.gapi = null;
        this.isInitialized = false;
        this.isAuthenticatedFlag = false;
    }

    // Inicializar Google Calendar API
    async initialize() {
        try {
            // Verificar configuración
            if (!this.apiKey || this.apiKey === 'TU_API_KEY_AQUI') {
                throw new Error('API Key no configurada correctamente');
            }
            
            if (!this.clientId || this.clientId === 'TU_CLIENT_ID_AQUI.apps.googleusercontent.com') {
                throw new Error('Client ID no configurado correctamente');
            }
            
            console.log('Inicializando Google Calendar API...');
            console.log('API Key:', this.apiKey.substring(0, 10) + '...');
            console.log('Client ID:', this.clientId.substring(0, 20) + '...');
            
            // Cargar Google API
            await this.loadGoogleAPI();
            
            // Inicializar gapi
            await this.initializeGAPI();
            
            // Verificar si hay un token en la URL (después de redirección)
            await this.checkForTokenInURL();
            
            this.isInitialized = true;
            console.log('✅ Google Calendar API inicializada correctamente');
            return true;
        } catch (error) {
            console.error('❌ Error al inicializar Google Calendar API:', error);
            this.showInitializationError(error);
            return false;
        }
    }

    // Cargar Google API
    loadGoogleAPI() {
        return new Promise((resolve, reject) => {
            if (window.gapi) {
                resolve();
                return;
            }

            const script = document.createElement('script');
            script.src = 'https://apis.google.com/js/api.js';
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
        });
    }

    // Cargar Google Identity Services
    loadGoogleIdentityServices() {
        return new Promise((resolve, reject) => {
            if (window.google && window.google.accounts) {
                resolve();
                return;
            }
            
            const script = document.createElement('script');
            script.src = 'https://accounts.google.com/gsi/client';
            script.onload = () => {
                console.log('✅ Google Identity Services cargada');
                resolve();
            };
            script.onerror = () => {
                reject(new Error('Error al cargar Google Identity Services'));
            };
            document.head.appendChild(script);
        });
    }

    // Inicializar gapi
    async initializeGAPI() {
        return new Promise((resolve, reject) => {
            gapi.load('client', async () => {
                try {
                    await gapi.client.init({
                        apiKey: this.apiKey,
                        discoveryDocs: [this.discoveryDoc]
                    });
                    
                    this.gapi = gapi;
                    resolve();
                } catch (error) {
                    reject(error);
                }
            });
        });
    }

    // Autenticar usuario
    async authenticate() {
        if (!this.isInitialized) {
            throw new Error('Google Calendar API no está inicializada');
        }

        try {
            // Cargar Google Identity Services si no está cargada
            await this.loadGoogleIdentityServices();
            
            // Intentar autenticación con popup primero
            try {
                return await this.authenticateWithPopup();
            } catch (popupError) {
                console.log('⚠️ Popup bloqueado, intentando con redirección...');
                return await this.authenticateWithRedirect();
            }
        } catch (error) {
            console.error('Error en autenticación:', error);
            throw error;
        }
    }

    // Autenticación con popup (método original)
    async authenticateWithPopup() {
        return new Promise((resolve, reject) => {
            const tokenClient = google.accounts.oauth2.initTokenClient({
                client_id: this.clientId,
                scope: 'https://www.googleapis.com/auth/calendar',
                callback: async (response) => {
                    if (response.error) {
                        reject(new Error(response.error));
                    } else {
                        // Configurar el token de acceso en gapi.client
                        gapi.client.setToken(response);
                        this.isAuthenticatedFlag = true;
                        resolve(response);
                    }
                }
            });
            
            tokenClient.requestAccessToken();
        });
    }

    // Autenticación con redirección (método alternativo)
    async authenticateWithRedirect() {
        return new Promise((resolve, reject) => {
            // Crear URL de autorización de Google
            const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?` +
                `client_id=${this.clientId}&` +
                `redirect_uri=${encodeURIComponent(window.location.origin + window.location.pathname)}&` +
                `scope=${encodeURIComponent('https://www.googleapis.com/auth/calendar')}&` +
                `response_type=token&` +
                `include_granted_scopes=true&` +
                `state=google_calendar_auth`;

            // Verificar si ya tenemos un token en la URL (después de redirección)
            const urlParams = new URLSearchParams(window.location.hash.substring(1));
            const accessToken = urlParams.get('access_token');
            const error = urlParams.get('error');

            if (accessToken) {
                // Tenemos el token, configurarlo
                const token = { access_token: accessToken };
                gapi.client.setToken(token);
                this.isAuthenticatedFlag = true;
                
                // Limpiar la URL
                window.history.replaceState({}, document.title, window.location.pathname);
                
                resolve(token);
            } else if (error) {
                reject(new Error(`Error de autorización: ${error}`));
            } else {
                // Redirigir a Google para autorización
                window.location.href = authUrl;
            }
        });
    }

    // Verificar si hay un token en la URL (después de redirección)
    async checkForTokenInURL() {
        try {
            const urlParams = new URLSearchParams(window.location.hash.substring(1));
            const accessToken = urlParams.get('access_token');
            const error = urlParams.get('error');

            if (accessToken) {
                console.log('🔑 Token encontrado en URL, configurando autenticación...');
                const token = { access_token: accessToken };
                gapi.client.setToken(token);
                this.isAuthenticatedFlag = true;
                
                // Limpiar la URL
                window.history.replaceState({}, document.title, window.location.pathname);
                
                console.log('✅ Autenticación automática completada desde URL');
                return true;
            } else if (error) {
                console.error('❌ Error de autorización en URL:', error);
                return false;
            }
            
            return false;
        } catch (error) {
            console.error('❌ Error al verificar token en URL:', error);
            return false;
        }
    }

    // Cerrar sesión
    async signOut() {
        if (!this.isInitialized) return;

        try {
            // Revocar el token y limpiar el estado
            if (this.gapi && this.gapi.client) {
                this.gapi.client.setToken(null);
            }
            this.isAuthenticatedFlag = false;
        } catch (error) {
            console.error('Error al cerrar sesión:', error);
        }
    }

    // Verificar si el usuario está autenticado
    isAuthenticated() {
        return this.isInitialized && this.isAuthenticatedFlag;
    }

    // Crear evento de cirugía en Google Calendar
    async createSurgeryEvent(surgicalEvent) {
        if (!this.isAuthenticated()) {
            throw new Error('Usuario no autenticado');
        }

        try {
            const event = {
                summary: `🏥 ${surgicalEvent.title}`,
                description: this.createEventDescription(surgicalEvent),
                start: {
                    dateTime: surgicalEvent.startDateTime,
                    timeZone: 'America/Mexico_City'
                },
                end: {
                    dateTime: surgicalEvent.endDateTime,
                    timeZone: 'America/Mexico_City'
                },
                location: `Habitación ${surgicalEvent.roomNumber}`,
                // attendees: this.createAttendees(surgicalEvent.medicalTeam), // Comentado: no crear asistentes
                reminders: {
                    useDefault: false,
                    overrides: [
                        { method: 'popup', minutes: 30 },
                        { method: 'popup', minutes: 60 },
                        { method: 'popup', minutes: 1440 } // 24 horas antes
                    ]
                },
                colorId: this.getColorIdByPriority(surgicalEvent.priority),
                extendedProperties: {
                    private: {
                        surgicalEventId: surgicalEvent.id,
                        specialty: surgicalEvent.specialty,
                        procedure: surgicalEvent.procedure,
                        patientId: surgicalEvent.patientId,
                        status: surgicalEvent.status
                    }
                }
            };

            const response = await this.gapi.client.calendar.events.insert({
                calendarId: 'primary',
                resource: event
            });

            return response.result;
        } catch (error) {
            console.error('Error al crear evento en Google Calendar:', error);
            throw error;
        }
    }

    // Actualizar evento de cirugía en Google Calendar
    async updateSurgeryEvent(surgicalEvent) {
        if (!this.isAuthenticated()) {
            throw new Error('Usuario no autenticado');
        }

        if (!surgicalEvent.googleCalendarEventId) {
            throw new Error('ID del evento de Google Calendar no encontrado');
        }

        try {
            const event = {
                summary: `🏥 ${surgicalEvent.title}`,
                description: this.createEventDescription(surgicalEvent),
                start: {
                    dateTime: surgicalEvent.startDateTime,
                    timeZone: 'America/Mexico_City'
                },
                end: {
                    dateTime: surgicalEvent.endDateTime,
                    timeZone: 'America/Mexico_City'
                },
                location: `Habitación ${surgicalEvent.roomNumber}`,
                // attendees: this.createAttendees(surgicalEvent.medicalTeam), // Comentado: no crear asistentes
                reminders: {
                    useDefault: false,
                    overrides: [
                        { method: 'popup', minutes: 30 },
                        { method: 'popup', minutes: 60 },
                        { method: 'popup', minutes: 1440 }
                    ]
                },
                colorId: this.getColorIdByPriority(surgicalEvent.priority),
                extendedProperties: {
                    private: {
                        surgicalEventId: surgicalEvent.id,
                        specialty: surgicalEvent.specialty,
                        procedure: surgicalEvent.procedure,
                        patientId: surgicalEvent.patientId,
                        status: surgicalEvent.status
                    }
                }
            };

            const response = await this.gapi.client.calendar.events.update({
                calendarId: 'primary',
                eventId: surgicalEvent.googleCalendarEventId,
                resource: event
            });

            return response.result;
        } catch (error) {
            console.error('Error al actualizar evento en Google Calendar:', error);
            throw error;
        }
    }

    // Eliminar evento de cirugía de Google Calendar
    async deleteSurgeryEvent(googleCalendarEventId) {
        if (!this.isAuthenticated()) {
            throw new Error('Usuario no autenticado');
        }

        try {
            await this.gapi.client.calendar.events.delete({
                calendarId: 'primary',
                eventId: googleCalendarEventId
            });

            return true;
        } catch (error) {
            console.error('Error al eliminar evento de Google Calendar:', error);
            throw error;
        }
    }

    // Obtener eventos de cirugía de Google Calendar
    async getSurgeryEvents(startDate, endDate) {
        console.log('🚀 INICIANDO getSurgeryEvents...');
        console.log('🔐 Verificando autenticación...');
        
        if (!this.isAuthenticated()) {
            console.log('❌ Usuario no autenticado');
            throw new Error('Usuario no autenticado');
        }
        
        console.log('✅ Usuario autenticado correctamente');

        try {
            console.log('🔍 Obteniendo eventos de Google Calendar...');
            console.log('📅 Rango de fechas:', startDate, 'a', endDate);
            
            // Primero obtener la lista de calendarios disponibles
            console.log('📋 Obteniendo lista de calendarios...');
            const calendarsResponse = await this.gapi.client.calendar.calendarList.list();
            console.log('📋 Respuesta de calendarios:', calendarsResponse);
            
            const calendars = calendarsResponse.result.items || [];
            console.log('📅 Calendarios disponibles:', calendars.length);
            calendars.forEach((cal, index) => {
                console.log(`  ${index + 1}. ${cal.summary} (${cal.id})`);
            });
            
            // Buscar eventos en todos los calendarios
            let allEvents = [];
            
            for (const calendar of calendars) {
                try {
                    console.log(`🔍 Buscando en calendario: ${calendar.summary} (ID: ${calendar.id})`);
                    
                    // Buscar eventos en el rango completo especificado
                    console.log(`  📅 Buscando eventos en rango: ${startDate} a ${endDate}`);
                    
                    // Verificar las fechas específicas
                    const startDateObj = new Date(startDate);
                    const endDateObj = new Date(endDate);
                    console.log(`  📅 Fecha inicio: ${startDateObj.toLocaleDateString()}`);
                    console.log(`  📅 Fecha fin: ${endDateObj.toLocaleDateString()}`);
                    
                    // Implementar paginación para obtener TODOS los eventos
                    let allCalendarEvents = [];
                    let nextPageToken = null;
                    let pageCount = 0;
                    
                    do {
                        pageCount++;
                        console.log(`  📄 Obteniendo página ${pageCount}...`);
                        
                        const requestParams = {
                            calendarId: calendar.id,
                            timeMin: startDate,
                            timeMax: endDate,
                            singleEvents: true,
                            orderBy: 'startTime',
                            maxResults: 250 // Máximo por página
                        };
                        
                        if (nextPageToken) {
                            requestParams.pageToken = nextPageToken;
                        }
                        
                        const response = await this.gapi.client.calendar.events.list(requestParams);
                        
                        const pageEvents = response.result.items || [];
                        allCalendarEvents = allCalendarEvents.concat(pageEvents);
                        
                        console.log(`  📄 Página ${pageCount}: ${pageEvents.length} eventos`);
                        console.log(`  📄 Total acumulado: ${allCalendarEvents.length} eventos`);
                        
                        nextPageToken = response.result.nextPageToken;
                        
                        if (nextPageToken) {
                            console.log(`  📄 Hay más páginas, continuando...`);
                        }
                        
                    } while (nextPageToken && pageCount < 10); // Límite de seguridad
                    
                    console.log(`  📄 Paginación completada: ${pageCount} páginas, ${allCalendarEvents.length} eventos totales`);
                    
                    const calendarEvents = allCalendarEvents;
                    console.log(`  📊 Eventos encontrados: ${calendarEvents.length}`);
                    
                    // Analizar las fechas de los eventos encontrados de manera más eficiente
                    if (calendarEvents.length > 0) {
                        console.log(`  🔍 Analizando fechas de ${calendarEvents.length} eventos...`);
                        
                        // Contar eventos por mes de manera más eficiente
                        const eventsByMonth = {};
                        let augustCount = 0;
                        let septemberCount = 0;
                        
                        for (let i = 0; i < calendarEvents.length; i++) {
                            const event = calendarEvents[i];
                            const eventDate = event.start?.dateTime || event.start?.date;
                            
                            if (eventDate) {
                                const date = new Date(eventDate);
                                const month = date.getMonth() + 1;
                                const year = date.getFullYear();
                                const key = `${year}-${month}`;
                                
                                eventsByMonth[key] = (eventsByMonth[key] || 0) + 1;
                                
                                // Contar específicamente agosto y septiembre 2025
                                if (year === 2025) {
                                    if (month === 8) augustCount++;
                                    if (month === 9) septemberCount++;
                                }
                            }
                        }
                        
                        console.log(`  📅 Eventos por mes:`, eventsByMonth);
                        console.log(`  📅 Eventos de agosto 2025: ${augustCount}`);
                        console.log(`  📅 Eventos de septiembre 2025: ${septemberCount}`);
                        
                        // Mostrar solo los primeros 3 eventos para no saturar
                        console.log(`  🔍 Primeros 3 eventos:`);
                        for (let i = 0; i < Math.min(3, calendarEvents.length); i++) {
                            const event = calendarEvents[i];
                            console.log(`    ${i + 1}. ${event.summary} - ${event.start?.dateTime || event.start?.date}`);
                        }
                    }
                    
                    allEvents = allEvents.concat(calendarEvents);
                    console.log(`  ✅ Eventos agregados al total. Total acumulado: ${allEvents.length}`);
                } catch (error) {
                    console.log(`  ⚠️ Error accediendo al calendario ${calendar.summary}:`, error);
                    console.log(`  ⚠️ Detalles del error:`, error.message);
                }
            }
            
            console.log('📊 Total de eventos encontrados:', allEvents.length);
            
            // Filtrar eventos creados por la cuenta específica de CMQ de manera más eficiente
            console.log('🔍 Verificando que sean eventos de CMQ...');
            
            const cmqEvents = [];
            let cmqCount = 0;
            
            for (let i = 0; i < allEvents.length; i++) {
                const event = allEvents[i];
                const creator = event.creator || {};
                const organizer = event.organizer || {};
                
                const creatorEmail = creator.email || '';
                const organizerEmail = organizer.email || '';
                
                // Buscar la cuenta específica de CMQ
                const isCreatedByCMQ = creatorEmail.includes('cmquirurgica.sanjose') || 
                                     organizerEmail.includes('cmquirurgica.sanjose') ||
                                     creatorEmail.includes('cmq') ||
                                     organizerEmail.includes('cmq') ||
                                     creatorEmail.includes('cmquirurgica') ||
                                     organizerEmail.includes('cmquirurgica') ||
                                     creatorEmail.includes('sanjose') ||
                                     organizerEmail.includes('sanjose');
                
                if (isCreatedByCMQ) {
                    cmqEvents.push(event);
                    cmqCount++;
                    
                    // Log solo los primeros 5 eventos de CMQ
                    if (cmqCount <= 5) {
                        console.log(`✅ Evento de CMQ ${cmqCount}: ${event.summary} (${creatorEmail})`);
                    }
                }
            }
            
            console.log('🏥 Eventos de CMQ encontrados:', cmqEvents.length);
            
            if (cmqEvents.length > 5) {
                console.log(`  ... y ${cmqEvents.length - 5} eventos más de CMQ`);
            }
            
            console.log('🎯 DEVOLVIENDO EVENTOS:', cmqEvents.length, 'eventos');
            return cmqEvents;
        } catch (error) {
            console.error('Error al obtener eventos de Google Calendar:', error);
            throw error;
        }
    }

    // Crear descripción del evento
    createEventDescription(surgicalEvent) {
        const team = surgicalEvent.medicalTeam;
        let description = `🏥 CIRUGÍA PROGRAMADA\n\n`;
        description += `👤 Paciente: ${surgicalEvent.patientName}\n`;
        description += `🏥 Habitación: ${surgicalEvent.roomNumber}\n`;
        description += `🔬 Especialidad: ${surgicalEvent.specialty}\n`;
        description += `⚕️ Procedimiento: ${surgicalEvent.procedure}\n`;
        description += `⏱️ Duración estimada: ${surgicalEvent.estimatedDuration} minutos\n`;
        description += `📊 Prioridad: ${surgicalEvent.priority}\n\n`;
        
        description += `👥 EQUIPO MÉDICO:\n`;
        if (team.treatingDoctor) description += `• Médico Tratante: ${team.treatingDoctor}\n`;
        if (team.surgeon) description += `• Cirujano: ${team.surgeon}\n`;
        if (team.assistant) description += `• Ayudante: ${team.assistant}\n`;
        if (team.anesthesiologist) description += `• Anestesiólogo: ${team.anesthesiologist}\n`;
        if (team.instrumentNurse) description += `• Enfermera Instrumentista: ${team.instrumentNurse}\n`;
        if (team.circulatingNurse) description += `• Enfermera Circulante: ${team.circulatingNurse}\n`;
        if (team.scrubNurse) description += `• Enfermera de Campo: ${team.scrubNurse}\n`;
        
        if (surgicalEvent.notes) {
            description += `\n📝 NOTAS:\n${surgicalEvent.notes}`;
        }
        
        if (surgicalEvent.preoperativeNotes) {
            description += `\n\n🔍 NOTAS PREOPERATORIAS:\n${surgicalEvent.preoperativeNotes}`;
        }

        return description;
    }

    // Crear lista de asistentes
    createAttendees(medicalTeam) {
        const attendees = [];
        
        // Solo agregar asistentes si tienen nombres válidos y no están vacíos
        if (medicalTeam.surgeon && medicalTeam.surgeon.trim() !== '') {
            const email = this.getEmailFromName(medicalTeam.surgeon);
            if (this.isValidEmail(email)) {
                attendees.push({ email: email, displayName: medicalTeam.surgeon });
            }
        }
        if (medicalTeam.assistant && medicalTeam.assistant.trim() !== '') {
            const email = this.getEmailFromName(medicalTeam.assistant);
            if (this.isValidEmail(email)) {
                attendees.push({ email: email, displayName: medicalTeam.assistant });
            }
        }
        if (medicalTeam.anesthesiologist && medicalTeam.anesthesiologist.trim() !== '') {
            const email = this.getEmailFromName(medicalTeam.anesthesiologist);
            if (this.isValidEmail(email)) {
                attendees.push({ email: email, displayName: medicalTeam.anesthesiologist });
            }
        }
        if (medicalTeam.instrumentNurse && medicalTeam.instrumentNurse.trim() !== '') {
            const email = this.getEmailFromName(medicalTeam.instrumentNurse);
            if (this.isValidEmail(email)) {
                attendees.push({ email: email, displayName: medicalTeam.instrumentNurse });
            }
        }
        
        return attendees;
    }

    // Obtener email desde nombre (función auxiliar)
    getEmailFromName(name) {
        // Limpiar el nombre y crear un email válido
        const cleanName = name.toLowerCase()
            .replace(/[^a-z0-9\s]/g, '') // Remover caracteres especiales
            .replace(/\s+/g, '.') // Reemplazar espacios con puntos
            .replace(/\.+/g, '.') // Remover puntos múltiples
            .replace(/^\.|\.$/g, ''); // Remover puntos al inicio y final
        
        // Si el nombre está vacío después de limpiar, usar un valor por defecto
        if (!cleanName || cleanName.length === 0) {
            return 'medico@clinica.com';
        }
        
        return `${cleanName}@clinica.com`;
    }

    // Validar si un email es válido
    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    // Obtener color por prioridad
    getColorIdByPriority(priority) {
        const colors = {
            'URGENTE': '11', // Rojo
            'ALTA': '6',     // Naranja
            'NORMAL': '10',  // Verde
            'BAJA': '5'      // Amarillo
        };
        return colors[priority] || '10';
    }

    // Sincronizar eventos con Firebase
    async syncWithFirebase(surgicalEvents) {
        try {
            // Obtener eventos de Google Calendar
            const startDate = new Date();
            startDate.setMonth(startDate.getMonth() - 1); // Último mes
            
            const endDate = new Date();
            endDate.setMonth(endDate.getMonth() + 3); // Próximos 3 meses
            
            const googleEvents = await this.getSurgeryEvents(startDate.toISOString(), endDate.toISOString());
            
            // Procesar eventos y sincronizar con Firebase
            for (const googleEvent of googleEvents) {
                const surgicalEventId = googleEvent.extendedProperties?.private?.surgicalEventId;
                
                if (surgicalEventId) {
                    // Actualizar evento existente
                    const surgicalEvent = surgicalEvents.find(e => e.id === surgicalEventId);
                    if (surgicalEvent) {
                        surgicalEvent.googleCalendarEventId = googleEvent.id;
                        // Actualizar en Firebase
                        await this.updateSurgicalEventInFirebase(surgicalEvent);
                    }
                }
            }
            
            return true;
        } catch (error) {
            console.error('Error en sincronización con Firebase:', error);
            throw error;
        }
    }

    // Actualizar evento quirúrgico en Firebase
    async updateSurgicalEventInFirebase(surgicalEvent) {
        // Esta función se implementará cuando integremos con Firebase
        console.log('Actualizando evento quirúrgico en Firebase:', surgicalEvent);
    }

    // Mostrar error de inicialización
    showInitializationError(error) {
        const errorDiv = document.createElement('div');
        errorDiv.style.cssText = `
            position: fixed;
            top: 20px;
            left: 20px;
            background: #e74c3c;
            color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
            z-index: 10000;
            max-width: 500px;
            font-family: Arial, sans-serif;
        `;
        
        errorDiv.innerHTML = `
            <h3 style="margin: 0 0 10px 0;">❌ Error de Inicialización</h3>
            <p style="margin: 0 0 15px 0;"><strong>Error:</strong> ${error.message}</p>
            <p style="margin: 0 0 15px 0;">Verifica que:</p>
            <ul style="margin: 0 0 15px 0; padding-left: 20px;">
                <li>La API Key esté correctamente configurada</li>
                <li>El Client ID esté correctamente configurado</li>
                <li>Google Calendar API esté habilitada en tu proyecto</li>
                <li>Los dominios estén autorizados</li>
            </ul>
            <button onclick="showConfigurationModal()" style="
                background: #2c3e50;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 5px;
                cursor: pointer;
                font-weight: bold;
                margin-right: 10px;
            ">Reconfigurar</button>
            <button onclick="this.parentElement.remove()" style="
                background: transparent;
                color: white;
                border: 1px solid white;
                padding: 10px 20px;
                border-radius: 5px;
                cursor: pointer;
            ">Cerrar</button>
        `;
        
        document.body.appendChild(errorDiv);
    }

    // Eliminar evento del Google Calendar
    async deleteEvent(eventId) {
        try {
            console.log('🗑️ Eliminando evento del Google Calendar:', eventId);
            console.log('🔍 Estado de autenticación:', this.isAuthenticatedFlag);
            console.log('🔍 gapi disponible:', !!this.gapi);
            console.log('🔍 gapi.client disponible:', !!(this.gapi && this.gapi.client));
            
            if (!this.isAuthenticatedFlag) {
                throw new Error('No estás autenticado con Google Calendar');
            }
            
            if (!eventId) {
                throw new Error('ID del evento no proporcionado');
            }
            
            if (!this.gapi || !this.gapi.client) {
                throw new Error('Google API no está disponible');
            }
            
            console.log('🔍 Llamando a gapi.client.calendar.events.delete...');
            const response = await this.gapi.client.calendar.events.delete({
                calendarId: 'primary',
                eventId: eventId
            });
            
            console.log('✅ Evento eliminado del Google Calendar:', eventId);
            console.log('🔍 Respuesta de Google Calendar:', response);
            return response;
            
        } catch (error) {
            console.error('❌ Error al eliminar evento del Google Calendar:', error);
            console.error('❌ Detalles del error:', error.message);
            throw error;
        }
    }
}

// Exportar clase
if (typeof module !== 'undefined' && module.exports) {
    module.exports = GoogleCalendarIntegration;
}
