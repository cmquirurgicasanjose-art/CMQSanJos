# 🚨 Solución: "Failed to get document because the client is offline"

## 🔍 **¿Qué significa este error?**

El error `Failed to get document because the client is offline` indica que **Firestore está en modo offline** y no puede conectarse a los servidores de Firebase. Esto es diferente a no tener internet - es un problema específico de Firestore.

## 🛠️ **Soluciones inmediatas:**

### **Solución 1: Recargar la página (Más efectiva)**
1. **Haz clic en "🔄 Recargar Página"**
2. **O presiona F5**
3. **Intenta hacer login nuevamente**

### **Solución 2: Forzar Firestore online**
1. **Haz clic en "🌐 Forzar Online"**
2. **Espera a que aparezca el mensaje de éxito en la consola**
3. **Intenta hacer login**

### **Solución 3: Limpiar caché y recargar**
1. **Haz clic en "🔄 Limpiar Caché"**
2. **Haz clic en "🔄 Recargar Página"**
3. **Intenta hacer login**

## 🔧 **Soluciones técnicas:**

### **Opción 1: Recargar completamente**
```javascript
// En la consola del navegador
location.reload(true);
```

### **Opción 2: Limpiar caché del navegador**
1. **Presiona Ctrl+Shift+Delete**
2. **Selecciona "Caché" y "Datos de sitios web"**
3. **Haz clic en "Limpiar datos"**
4. **Recarga la página**

### **Opción 3: Modo incógnito**
1. **Abre una ventana incógnita (Ctrl+Shift+N)**
2. **Ve a la página web**
3. **Intenta hacer login**

## 🔍 **Diagnóstico paso a paso:**

### **Paso 1: Verificar el estado**
1. **Abre la consola (F12)**
2. **Haz clic en "🔍 Probar Conexión"**
3. **Mira los mensajes:**

**✅ Si aparece:**
```
✅ Firebase inicializado correctamente
✅ Conexión con Firestore exitosa
```
**→ Todo está bien, intenta hacer login**

**❌ Si aparece:**
```
❌ Error de conexión con Firestore: FirebaseError: Failed to get document because the client is offline
```
**→ Usa las soluciones de arriba**

### **Paso 2: Verificar en la consola**
Busca estos mensajes:
- `✅ Firebase inicializado correctamente`
- `✅ Conexión con Firestore exitosa`
- `❌ Error de conexión con Firestore`

## 🚀 **Solución rápida (Recomendada):**

**Para la mayoría de casos, esto funciona:**

1. **Haz clic en "🔄 Recargar Página"**
2. **Espera a que cargue completamente**
3. **Intenta hacer login**

## 🔄 **Si el problema persiste:**

### **Verificar desde la app Android:**
1. **Abre la app Android**
2. **Intenta hacer login**
3. **Si funciona en Android pero no en web:**
   - Problema específico del navegador
   - Usar modo incógnito

### **Verificar configuración de Firebase:**
1. **Ve a [Firebase Console](https://console.firebase.google.com/)**
2. **Selecciona tu proyecto**
3. **Ve a Firestore Database**
4. **Verifica que esté activo**

### **Verificar reglas de Firestore:**
1. **En Firebase Console > Firestore > Rules**
2. **Verifica que las reglas permitan lectura:**
   ```javascript
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /users/{userId} {
         allow read, write: if request.auth != null && request.auth.uid == userId;
       }
     }
   }
   ```

## 📱 **Verificación final:**

Para confirmar que está solucionado:
1. ✅ **"🔍 Probar Conexión"** muestra éxito
2. ✅ **Login funciona** sin errores
3. ✅ **No hay errores** en la consola
4. ✅ **Funciona en Android** también

## 🆘 **Si nada funciona:**

### **Crear usuario de prueba:**
1. **Haz clic en "Crear Nueva Cuenta"**
2. **Crea un usuario de prueba**
3. **Intenta hacer login con el nuevo usuario**

### **Verificar desde otro dispositivo:**
1. **Usa otro computador/tablet**
2. **Abre la página web**
3. **Intenta hacer login**

## 💡 **Prevención:**

Para evitar este problema en el futuro:
1. **No dejes la página abierta por mucho tiempo**
2. **Recarga la página si no has usado la app por un rato**
3. **Usa el botón "🔄 Recargar Página" si hay problemas**

## 🔧 **Comandos de diagnóstico:**

Ejecuta estos en la consola del navegador:

```javascript
// Verificar estado de Firestore
console.log('DB:', db);
console.log('Auth:', auth);

// Probar conexión
testFirebaseConnection();

// Forzar online
forceFirestoreOnline();
```

