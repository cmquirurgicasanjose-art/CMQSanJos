// Configuración de Firebase para Realtime Database
// IMPORTANTE: Reemplaza estos valores con tu configuración real de Firebase

const firebaseConfig = {
    apiKey: "AIzaSyACgsmCsd2r5KnwfQSlZlt20-YrpZbwJIw",
    authDomain: "cmqsanjos-clinica.firebaseapp.com",
    projectId: "cmqsanjos-clinica",
    storageBucket: "cmqsanjos-clinica.firebasestorage.app",
    messagingSenderId: "403556686078",
    appId: "1:403556686078:web:75b193e2e057b890806daf",
    measurementId: "G-CE0ZYRJT9F",
    databaseURL: "https://cmqsanjos-clinica-default-rtdb.firebaseio.com/"
};

// Función para inicializar Firebase con Realtime Database
function initializeFirebaseRealtime() {
    if (typeof firebase !== 'undefined') {
        try {
            const app = firebase.initializeApp(firebaseConfig);
            const auth = firebase.auth();
            const database = firebase.database();
            
            console.log('✅ Firebase Realtime Database inicializado correctamente');
            
            return {
                auth: auth,
                database: database,
                app: app
            };
        } catch (error) {
            console.error('❌ Error al inicializar Firebase Realtime Database:', error);
            return null;
        }
    } else {
        console.error('❌ Firebase SDK no está cargado');
        return null;
    }
}

// Función para probar conexión a Realtime Database
async function testRealtimeDatabaseConnection() {
    try {
        const { database } = initializeFirebaseRealtime();
        if (!database) {
            throw new Error('No se pudo inicializar Firebase');
        }
        
        // Probar lectura de datos
        const snapshot = await database.ref('test').once('value');
        console.log('✅ Conexión a Realtime Database exitosa');
        return true;
    } catch (error) {
        console.error('❌ Error de conexión a Realtime Database:', error);
        return false;
    }
}

// Función para obtener datos de usuario desde Realtime Database
async function getUserDataFromRealtime(userId) {
    try {
        const { database } = initializeFirebaseRealtime();
        if (!database) {
            throw new Error('No se pudo inicializar Firebase');
        }
        
        const snapshot = await database.ref(`users/${userId}`).once('value');
        
        if (snapshot.exists()) {
            const userData = snapshot.val();
            console.log('✅ Datos de usuario obtenidos de Realtime Database:', userData);
            return userData;
        } else {
            console.log('⚠️ Usuario no encontrado en Realtime Database');
            return null;
        }
    } catch (error) {
        console.error('❌ Error al obtener datos de usuario:', error);
        return null;
    }
}

// Función para guardar datos de usuario en Realtime Database
async function saveUserToRealtime(userData) {
    try {
        const { database } = initializeFirebaseRealtime();
        if (!database) {
            throw new Error('No se pudo inicializar Firebase');
        }
        
        await database.ref(`users/${userData.id}`).set(userData);
        console.log('✅ Usuario guardado en Realtime Database:', userData);
        return true;
    } catch (error) {
        console.error('❌ Error al guardar usuario en Realtime Database:', error);
        return false;
    }
}

// Función para sincronizar datos con localStorage
function syncWithLocalStorage(userData) {
    try {
        localStorage.setItem('current_user', JSON.stringify(userData));
        console.log('✅ Datos sincronizados con localStorage');
        return true;
    } catch (error) {
        console.error('❌ Error al sincronizar con localStorage:', error);
        return false;
    }
}

// Función para cargar datos desde localStorage
function loadFromLocalStorage() {
    try {
        const userData = localStorage.getItem('current_user');
        if (userData) {
            const parsed = JSON.parse(userData);
            console.log('✅ Datos cargados desde localStorage:', parsed);
            return parsed;
        }
        return null;
    } catch (error) {
        console.error('❌ Error al cargar desde localStorage:', error);
        return null;
    }
}

// Exportar funciones para uso global
window.initializeFirebaseRealtime = initializeFirebaseRealtime;
window.testRealtimeDatabaseConnection = testRealtimeDatabaseConnection;
window.getUserDataFromRealtime = getUserDataFromRealtime;
window.saveUserToRealtime = saveUserToRealtime;
window.syncWithLocalStorage = syncWithLocalStorage;
window.loadFromLocalStorage = loadFromLocalStorage;

