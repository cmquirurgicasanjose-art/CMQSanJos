#!/bin/bash
echo "Iniciando servidor web para Programación Quirúrgica..."
echo ""
echo "El servidor estará disponible en: http://localhost:8000"
echo ""
echo "Para detener el servidor, presiona Ctrl+C"
echo ""
python3 -m http.server 8000

