# 🔧 Solución de Problemas de Autenticación

## 🚨 Problema: "Error de autenticación. Intenta nuevamente"

### **Causas comunes:**

1. **Contraseña incorrecta** - La más común
2. **Caché de autenticación** - Datos antiguos en el navegador
3. **Usuario no existe** - Email incorrecto
4. **Problemas de conexión** - Internet o Firebase

### **🔍 Pasos para diagnosticar:**

#### **1. Verificar en la consola del navegador:**
1. Abre la página web
2. Presiona `F12` o `Ctrl+Shift+I`
3. Ve a la pestaña **Console**
4. Intenta hacer login
5. Busca mensajes como:
   - `Error de Firebase: auth/wrong-password`
   - `Error de Firebase: auth/user-not-found`
   - `Error de Firebase: auth/invalid-credential`

#### **2. Verificar en Firebase Console:**
1. Ve a [Firebase Console](https://console.firebase.google.com/)
2. Selecciona tu proyecto **CMQ San José**
3. Ve a **Authentication** > **Users**
4. Busca tu usuario por email
5. Verifica que esté activo

### **🛠️ Soluciones:**

#### **Solución 1: Limpiar caché de autenticación**
1. En la página web, haz clic en **"🔄 Limpiar Caché de Autenticación"**
2. Espera a que aparezca el mensaje en la consola
3. Intenta hacer login nuevamente

#### **Solución 2: Verificar contraseña**
1. **Desde la app Android:**
   - Intenta hacer login con la misma cuenta
   - Si funciona, la contraseña es correcta
   - Si no funciona, reinicia la contraseña

2. **Reiniciar contraseña desde Firebase:**
   - Ve a Firebase Console > Authentication > Users
   - Busca tu usuario
   - Haz clic en los 3 puntos > "Reset password"
   - Se enviará un email para reiniciar

#### **Solución 3: Verificar email**
1. Asegúrate de que el email sea exactamente el mismo
2. Verifica que no haya espacios extra
3. Verifica que esté en minúsculas

#### **Solución 4: Limpiar caché del navegador**
1. Presiona `Ctrl+Shift+Delete`
2. Selecciona "Caché" y "Datos de sitios web"
3. Haz clic en "Limpiar datos"
4. Recarga la página

### **🔍 Códigos de error específicos:**

| Código | Significado | Solución |
|--------|-------------|----------|
| `auth/wrong-password` | Contraseña incorrecta | Verificar o reiniciar contraseña |
| `auth/user-not-found` | Usuario no existe | Verificar email o crear cuenta |
| `auth/invalid-credential` | Credenciales inválidas | Limpiar caché y reintentar |
| `auth/too-many-requests` | Demasiados intentos | Esperar unos minutos |
| `auth/network-request-failed` | Problema de conexión | Verificar internet |

### **📱 Verificar desde la app Android:**

1. **Abre la app Android**
2. **Intenta hacer login** con las mismas credenciales
3. **Si funciona en Android pero no en web:**
   - Problema de caché en el navegador
   - Usar el botón "Limpiar Caché"
4. **Si no funciona en ninguno:**
   - Problema con las credenciales
   - Reiniciar contraseña desde Firebase

### **🆘 Si nada funciona:**

1. **Crear un nuevo usuario** desde la página web
2. **Verificar que se guarde** en Firebase Console
3. **Intentar hacer login** con el nuevo usuario
4. **Si funciona**, el problema era con el usuario anterior

### **📞 Información para debugging:**

Cuando reportes un problema, incluye:
- **Email** que estás usando
- **Mensaje de error** exacto
- **Código de error** de la consola
- **Si funciona en Android** o no
- **Navegador** que estás usando

### **✅ Verificación final:**

Para confirmar que todo funciona:
1. ✅ Login funciona en Android
2. ✅ Login funciona en web
3. ✅ Los datos se sincronizan entre ambos
4. ✅ No hay errores en la consola

