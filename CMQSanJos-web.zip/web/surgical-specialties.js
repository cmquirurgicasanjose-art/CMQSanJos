// Catálogo de Especialidades Quirúrgicas de México
const SURGICAL_SPECIALTIES = {
    GENERAL_SURGERY: {
        name: "Cirugía General",
        procedures: [
            "Apendicectomía",
            "Laparotomía",
            "Laparoscopia",
            "Colecistectomía Laparoscópica",
            "Apendicectomía Laparoscópica",
            "Funduplicatura Laparoscópica",
            "Hernia Inguinal",
            "Hernia Umbilical",
            "Hernia Ventral",
            "Gastrectomía",
            "Colectomía",
            "Esplenectomía",
            "Pancreatectomía",
            "Tiroidectomía",
            "Paratiroidectomía",
            "Mastectomía",
            "Linfadenectomía"
        ]
    },
    GYNECOLOGY: {
        name: "Ginecología",
        procedures: [
            "Laparotomía Exploradora",
            "Histerectomía",
            "Cesárea",
            "Ooforectomía",
            "Salpingectomía",
            "Miomectomía",
            "Laparoscopia Ginecológica",
            "Histeroscopia",
            "Colposcopia",
            "Conización",
            "Ligadura de Trompas",
            "Reversión de Ligadura",
            "Cirugía de Endometriosis",
            "Cirugía de Prolapso",
            "Cirugía de Incontinencia"
        ]
    },
    TRAUMATOLOGY_ORTHOPEDICS: {
        name: "Traumatología y Ortopedia",
        procedures: [
            "Artroscopia de Rodilla",
            "Artroscopia de Hombro",
            "Artroscopia de Tobillo",
            "Prótesis de Cadera",
            "Prótesis de Rodilla",
            "Prótesis de Hombro",
            "Osteosíntesis",
            "Reducción de Fracturas",
            "Cirugía de Columna",
            "Discectomía",
            "Laminectomía",
            "Fusión Vertebral",
            "Cirugía de Menisco",
            "Reconstrucción de Ligamentos",
            "Cirugía de Pie y Tobillo",
            "Cirugía de Mano"
        ]
    },
    OPHTHALMOLOGY: {
        name: "Oftalmología",
        procedures: [
            "Catarata",
            "Glaucoma",
            "Retina",
            "Vitrectomía",
            "Cirugía de Párpados",
            "Cirugía de Vías Lagrimales",
            "Cirugía de Estrabismo",
            "Cirugía Refractiva",
            "Transplante de Córnea",
            "Cirugía de Desprendimiento de Retina",
            "Cirugía de Macular",
            "Cirugía de Glaucoma",
            "Cirugía de Catarata Congénita"
        ]
    },
    PLASTIC_SURGERY: {
        name: "Cirugía Plástica",
        procedures: [
            "Rinoplastia",
            "Mamoplastia",
            "Abdominoplastia",
            "Liposucción",
            "Blefaroplastia",
            "Otoplastia",
            "Mentoplastia",
            "Cirugía de Quemaduras",
            "Reconstrucción Mamaria",
            "Cirugía de Labio Leporino",
            "Cirugía de Paladar Hendido",
            "Cirugía de Mano",
            "Cirugía de Cuero Cabelludo",
            "Cirugía de Párpados"
        ]
    },
    NEUROSURGERY: {
        name: "Neurocirugía",
        procedures: [
            "Craneotomía",
            "Cirugía de Tumor Cerebral",
            "Cirugía de Aneurisma",
            "Cirugía de Malformación Arteriovenosa",
            "Cirugía de Epilepsia",
            "Cirugía de Parkinson",
            "Cirugía de Columna",
            "Cirugía de Hernia Discal",
            "Cirugía de Estenosis",
            "Cirugía de Traumatismo Craneoencefálico",
            "Cirugía de Hidrocefalia",
            "Cirugía de Espina Bífida"
        ]
    },
    CARDIOVASCULAR_SURGERY: {
        name: "Cirugía Cardiovascular",
        procedures: [
            "Bypass Coronario",
            "Cirugía de Válvulas",
            "Cirugía de Aorta",
            "Cirugía de Arritmias",
            "Cirugía de Cardiopatías Congénitas",
            "Cirugía de Marcapasos",
            "Cirugía de Aneurisma Aórtico",
            "Cirugía de Endarterectomía",
            "Cirugía de Fístula Arteriovenosa",
            "Cirugía de Varices"
        ]
    },
    THORACIC_SURGERY: {
        name: "Cirugía Torácica",
        procedures: [
            "Lobectomía",
            "Neumonectomía",
            "Cirugía de Esófago",
            "Cirugía de Mediastino",
            "Cirugía de Pleura",
            "Cirugía de Diafragma",
            "Cirugía de Traumatismo Torácico",
            "Cirugía de Tumor Pulmonar",
            "Cirugía de Enfisema",
            "Cirugía de Neumotórax"
        ]
    },
    UROLOGY: {
        name: "Urología",
        procedures: [
            "Nefrectomía",
            "Cirugía de Próstata",
            "Cirugía de Vejiga",
            "Cirugía de Riñón",
            "Cirugía de Ureter",
            "Cirugía de Uretra",
            "Cirugía de Testículo",
            "Cirugía de Pene",
            "Cirugía de Incontinencia",
            "Cirugía de Litiasis",
            "Cirugía de Cáncer Urológico",
            "Cirugía de Infertilidad"
        ]
    },
    PEDIATRIC_SURGERY: {
        name: "Cirugía Pediátrica",
        procedures: [
            "Cirugía de Labio Leporino",
            "Cirugía de Paladar Hendido",
            "Cirugía de Atresia Esofágica",
            "Cirugía de Atresia Intestinal",
            "Cirugía de Hernia Inguinal",
            "Cirugía de Hernia Umbilical",
            "Cirugía de Testículo No Descendido",
            "Cirugía de Malformaciones Cardíacas",
            "Cirugía de Espina Bífida",
            "Cirugía de Hidrocefalia",
            "Cirugía de Tumores Pediátricos"
        ]
    },
    ONCOLOGY_SURGERY: {
        name: "Cirugía Oncológica",
        procedures: [
            "Cirugía de Cáncer de Mama",
            "Cirugía de Cáncer de Colon",
            "Cirugía de Cáncer de Pulmón",
            "Cirugía de Cáncer de Próstata",
            "Cirugía de Cáncer de Estómago",
            "Cirugía de Cáncer de Hígado",
            "Cirugía de Cáncer de Páncreas",
            "Cirugía de Cáncer de Tiroides",
            "Cirugía de Cáncer de Ovario",
            "Cirugía de Cáncer de Útero",
            "Cirugía de Cáncer de Riñón",
            "Cirugía de Cáncer de Vejiga"
        ]
    },
    VASCULAR_SURGERY: {
        name: "Cirugía Vascular",
        procedures: [
            "Cirugía de Aneurisma Aórtico",
            "Cirugía de Estenosis Carotídea",
            "Cirugía de Enfermedad Arterial Periférica",
            "Cirugía de Varices",
            "Cirugía de Fístula Arteriovenosa",
            "Cirugía de Trombosis",
            "Cirugía de Embolia",
            "Cirugía de Isquemia",
            "Cirugía de Gangrena",
            "Cirugía de Úlceras Venosas"
        ]
    },
    OTOLARYNGOLOGY: {
        name: "Otorrinolaringología",
        procedures: [
            "Cirugía de Amígdalas",
            "Cirugía de Adenoides",
            "Cirugía de Senos Paranasales",
            "Cirugía de Tabique Nasal",
            "Cirugía de Pólipos",
            "Cirugía de Oído",
            "Cirugía de Tímpano",
            "Cirugía de Mastoides",
            "Cirugía de Laringe",
            "Cirugía de Cáncer de Cabeza y Cuello",
            "Cirugía de Glándulas Salivales",
            "Cirugía de Tiroides"
        ]
    },
    MAXILLOFACIAL_SURGERY: {
        name: "Cirugía Maxilofacial",
        procedures: [
            "Cirugía de Fracturas Faciales",
            "Cirugía de Mandíbula",
            "Cirugía de Maxilar",
            "Cirugía de Cigomático",
            "Cirugía de Órbita",
            "Cirugía de Senos Paranasales",
            "Cirugía de Tumores",
            "Cirugía de Quistes",
            "Cirugía de Implantes",
            "Cirugía de Reconstrucción",
            "Cirugía de Labio Leporino",
            "Cirugía de Paladar Hendido"
        ]
    },
    OTHER: {
        name: "Otras Especialidades",
        procedures: [
            "Cirugía de Emergencia",
            "Cirugía de Traumatismo",
            "Cirugía de Quemaduras",
            "Cirugía de Transplante",
            "Cirugía de Cirugía Mínimamente Invasiva",
            "Cirugía Robótica",
            "Cirugía Endoscópica",
            "Cirugía Laparoscópica",
            "Cirugía Toracoscópica",
            "Cirugía Artroscópica"
        ]
    }
};

// Función para obtener todas las especialidades
function getAllSpecialties() {
    return Object.keys(SURGICAL_SPECIALTIES).map(key => ({
        id: key,
        name: SURGICAL_SPECIALTIES[key].name,
        procedures: SURGICAL_SPECIALTIES[key].procedures
    }));
}

// Función para obtener procedimientos de una especialidad
function getProceduresBySpecialty(specialtyId) {
    return SURGICAL_SPECIALTIES[specialtyId]?.procedures || [];
}

// Función para buscar procedimientos
function searchProcedures(query) {
    const results = [];
    Object.keys(SURGICAL_SPECIALTIES).forEach(specialtyId => {
        const specialty = SURGICAL_SPECIALTIES[specialtyId];
        specialty.procedures.forEach(procedure => {
            if (procedure.toLowerCase().includes(query.toLowerCase())) {
                results.push({
                    specialty: specialty.name,
                    procedure: procedure
                });
            }
        });
    });
    return results;
}

