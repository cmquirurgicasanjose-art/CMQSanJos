// Sistema de autenticación para la aplicación quirúrgica
class AuthSystem {
    constructor() {
        this.currentUser = null;
        this.isAuthenticated = false;
        this.authListeners = [];
        
        // Inicializar Firebase Auth
        this.initFirebaseAuth();
    }

    // Inicializar Firebase Authentication
    initFirebaseAuth() {
        try {
            // Verificar que Firebase esté disponible
            if (typeof firebase === 'undefined') {
                console.error('❌ Firebase no está disponible');
                return;
            }

            // Esperar a que Firebase esté inicializado
            this.waitForFirebase().then(() => {
                // Configurar el estado de autenticación
                firebase.auth().onAuthStateChanged((user) => {
                    if (user) {
                        this.currentUser = user;
                        this.isAuthenticated = true;
                        console.log('✅ Usuario autenticado:', user.email);
                        this.notifyAuthListeners(true, user);
                    } else {
                        this.currentUser = null;
                        this.isAuthenticated = false;
                        console.log('❌ Usuario no autenticado');
                        this.notifyAuthListeners(false, null);
                    }
                });

                console.log('✅ Sistema de autenticación inicializado');
            }).catch((error) => {
                console.error('❌ Error al inicializar autenticación:', error);
            });
        } catch (error) {
            console.error('❌ Error al inicializar autenticación:', error);
        }
    }

    // Esperar a que Firebase esté inicializado
    waitForFirebase() {
        return new Promise((resolve, reject) => {
            let attempts = 0;
            const maxAttempts = 30; // 3 segundos máximo
            
            const checkFirebase = () => {
                attempts++;
                
                // Verificar si Firebase está disponible y inicializado
                if (typeof firebase !== 'undefined' && firebase.apps && firebase.apps.length > 0) {
                    console.log('✅ Firebase inicializado correctamente para auth');
                    resolve();
                    return;
                }
                
                if (attempts >= maxAttempts) {
                    console.error('❌ Firebase no se pudo inicializar después de 3 segundos');
                    reject(new Error('Firebase no se pudo inicializar'));
                } else {
                    console.log(`⏳ Esperando Firebase para auth... (intento ${attempts}/${maxAttempts})`);
                    setTimeout(checkFirebase, 100);
                }
            };
            checkFirebase();
        });
    }

    // Registrar listener de cambios de autenticación
    onAuthStateChanged(callback) {
        this.authListeners.push(callback);
        
        // Si ya hay un usuario autenticado, llamar inmediatamente
        if (this.isAuthenticated && this.currentUser) {
            callback(true, this.currentUser);
        }
    }

    // Notificar a todos los listeners
    notifyAuthListeners(isAuthenticated, user) {
        this.authListeners.forEach(callback => {
            try {
                callback(isAuthenticated, user);
            } catch (error) {
                console.error('❌ Error en listener de autenticación:', error);
            }
        });
    }

    // Iniciar sesión con email y contraseña
    async signInWithEmailAndPassword(email, password) {
        try {
            console.log('🔐 Iniciando sesión con:', email);
            
            const userCredential = await firebase.auth().signInWithEmailAndPassword(email, password);
            this.currentUser = userCredential.user;
            this.isAuthenticated = true;
            
            console.log('✅ Sesión iniciada exitosamente');
            return { success: true, user: this.currentUser };
        } catch (error) {
            console.error('❌ Error al iniciar sesión:', error);
            return { success: false, error: error.message };
        }
    }

    // Registrar nuevo usuario
    async createUserWithEmailAndPassword(email, password) {
        try {
            console.log('👤 Creando usuario:', email);
            
            const userCredential = await firebase.auth().createUserWithEmailAndPassword(email, password);
            this.currentUser = userCredential.user;
            this.isAuthenticated = true;
            
            console.log('✅ Usuario creado exitosamente');
            return { success: true, user: this.currentUser };
        } catch (error) {
            console.error('❌ Error al crear usuario:', error);
            return { success: false, error: error.message };
        }
    }

    // Cerrar sesión
    async signOut() {
        try {
            console.log('🚪 Cerrando sesión...');
            
            await firebase.auth().signOut();
            this.currentUser = null;
            this.isAuthenticated = false;
            
            console.log('✅ Sesión cerrada exitosamente');
            return { success: true };
        } catch (error) {
            console.error('❌ Error al cerrar sesión:', error);
            return { success: false, error: error.message };
        }
    }

    // Obtener usuario actual
    getCurrentUser() {
        return this.currentUser;
    }

    // Verificar si está autenticado
    isUserAuthenticated() {
        return this.isAuthenticated;
    }

    // Obtener token de ID
    async getIdToken() {
        if (this.currentUser) {
            try {
                return await this.currentUser.getIdToken();
            } catch (error) {
                console.error('❌ Error al obtener token:', error);
                return null;
            }
        }
        return null;
    }

    // Actualizar perfil del usuario
    async updateProfile(displayName, photoURL) {
        if (this.currentUser) {
            try {
                await this.currentUser.updateProfile({
                    displayName: displayName,
                    photoURL: photoURL
                });
                console.log('✅ Perfil actualizado');
                return { success: true };
            } catch (error) {
                console.error('❌ Error al actualizar perfil:', error);
                return { success: false, error: error.message };
            }
        }
        return { success: false, error: 'No hay usuario autenticado' };
    }

    // Cambiar contraseña
    async changePassword(newPassword) {
        if (this.currentUser) {
            try {
                await this.currentUser.updatePassword(newPassword);
                console.log('✅ Contraseña actualizada');
                return { success: true };
            } catch (error) {
                console.error('❌ Error al cambiar contraseña:', error);
                return { success: false, error: error.message };
            }
        }
        return { success: false, error: 'No hay usuario autenticado' };
    }

    // Enviar email de restablecimiento de contraseña
    async sendPasswordResetEmail(email) {
        try {
            await firebase.auth().sendPasswordResetEmail(email);
            console.log('✅ Email de restablecimiento enviado');
            return { success: true };
        } catch (error) {
            console.error('❌ Error al enviar email:', error);
            return { success: false, error: error.message };
        }
    }

    // Verificar si el email está verificado
    isEmailVerified() {
        return this.currentUser ? this.currentUser.emailVerified : false;
    }

    // Enviar email de verificación
    async sendEmailVerification() {
        if (this.currentUser) {
            try {
                await this.currentUser.sendEmailVerification();
                console.log('✅ Email de verificación enviado');
                return { success: true };
            } catch (error) {
                console.error('❌ Error al enviar verificación:', error);
                return { success: false, error: error.message };
            }
        }
        return { success: false, error: 'No hay usuario autenticado' };
    }

    // Obtener información del usuario
    getUserInfo() {
        if (this.currentUser) {
            return {
                uid: this.currentUser.uid,
                email: this.currentUser.email,
                displayName: this.currentUser.displayName,
                photoURL: this.currentUser.photoURL,
                emailVerified: this.currentUser.emailVerified,
                creationTime: this.currentUser.metadata.creationTime,
                lastSignInTime: this.currentUser.metadata.lastSignInTime
            };
        }
        return null;
    }

    // Limpiar listeners
    cleanup() {
        this.authListeners = [];
    }
}

// Crear instancia global del sistema de autenticación
window.authSystem = new AuthSystem();

// Funciones globales para compatibilidad
window.signIn = (email, password) => window.authSystem.signInWithEmailAndPassword(email, password);
window.signUp = (email, password) => window.authSystem.createUserWithEmailAndPassword(email, password);
window.signOut = () => window.authSystem.signOut();
window.getCurrentUser = () => window.authSystem.getCurrentUser();
window.isAuthenticated = () => window.authSystem.isUserAuthenticated();

console.log('✅ Sistema de autenticación cargado');
