// Aplicación principal de programación quirúrgica
class SurgicalSchedulingApp {
    constructor() {
        this.calendar = null;
        this.surgicalEvents = [];
        this.googleCalendarIntegration = new GoogleCalendarIntegration();
        this.currentEditingEvent = null;
        this.patients = [];
        this.rooms = [];
        this.isSaving = false;
        this.currentDisplayDate = new Date(); // Fecha que se está mostrando en la lista
        
        this.init();
    }

    async init() {
        try {
            // Verificar configuración de Google Calendar
            if (!isGoogleCalendarConfigured()) {
                showConfigurationAlert();
            }
            
            await this.initializeGoogleCalendar();
            await this.loadData();
            
            // Inicializar calendario después de que la página esté completamente cargada
            if (document.readyState === 'complete') {
                this.setupEventListeners();
                this.loadSurgicalEvents();
                this.startAutoSync();
                // Intentar sincronización automática con Google Calendar
                this.attemptAutoSync();
                // Esperar un poco más para que FullCalendar se cargue
                setTimeout(() => {
                    this.initializeCalendar();
                }, 500);
            } else {
                    window.addEventListener('load', () => {
                        this.setupEventListeners();
                        this.loadSurgicalEvents();
                        this.startAutoSync();
                        // Intentar sincronización automática con Google Calendar
                        this.attemptAutoSync();
                        // Esperar un poco más para que FullCalendar se cargue
                        setTimeout(() => {
                            this.initializeCalendar();
                        }, 500);
                    });
                }
                
            } catch (error) {
                console.error('Error al inicializar la aplicación:', error);
                this.showAlert('Error al inicializar la aplicación', 'error');
            }
        }

    // Esperar a que Firebase esté inicializado
    waitForFirebase() {
        return new Promise((resolve, reject) => {
            let attempts = 0;
            const maxAttempts = 30; // 3 segundos máximo
            
            const checkFirebase = () => {
                attempts++;
                
                // Verificar si Firebase está disponible y inicializado
                if (typeof firebase !== 'undefined' && firebase.apps && firebase.apps.length > 0) {
                    console.log('✅ Firebase inicializado correctamente');
                    resolve();
                    return;
                }
                
                if (attempts >= maxAttempts) {
                    console.error('❌ Firebase no se pudo inicializar después de 3 segundos');
                    console.error('Debug info:', {
                        firebaseDefined: typeof firebase !== 'undefined',
                        firebaseApps: firebase?.apps?.length || 0,
                        windowFirebaseApp: !!window.firebaseApp
                    });
                    reject(new Error('Firebase no se pudo inicializar'));
                } else {
                    console.log(`⏳ Esperando Firebase... (intento ${attempts}/${maxAttempts})`);
                    setTimeout(checkFirebase, 100);
                }
            };
            checkFirebase();
        });
    }

    // Esperar a que FullCalendar se cargue (DESHABILITADO)
    waitForFullCalendar() {
        return new Promise((resolve, reject) => {
            console.log('📅 FullCalendar deshabilitado - usando calendario simple');
            console.log('✅ Saltando carga de FullCalendar');
            resolve(); // Resolver inmediatamente para usar calendario simple
        });
    }

    // Inicializar Google Calendar
    async initializeGoogleCalendar() {
        try {
            const success = await this.googleCalendarIntegration.initialize();
            if (success) {
                console.log('Google Calendar API inicializada correctamente');
            }
        } catch (error) {
            console.error('Error al inicializar Google Calendar:', error);
        }
    }

    // Cargar datos iniciales
    async loadData() {
        try {
            // Cargar pacientes ocupados
            await this.loadOccupiedPatients();
            
            // Cargar habitaciones
            await this.loadRooms();
            
            // Cargar especialidades quirúrgicas
            this.loadSurgicalSpecialties();
        } catch (error) {
            console.error('Error al cargar datos:', error);
        }
    }

    // Cargar pacientes ocupados
    async loadOccupiedPatients() {
        try {
            // Simular carga de pacientes ocupados desde Firebase
            // En la implementación real, esto vendría de Firebase
            this.patients = [
                { id: 'patient_1', name: 'Juan Pérez', roomNumber: '101' },
                { id: 'patient_2', name: 'María García', roomNumber: '103' },
                { id: 'patient_3', name: 'Carlos López', roomNumber: '105' }
            ];
            
            // Ya no necesitamos poblar selector de pacientes
        } catch (error) {
            console.error('Error al cargar pacientes:', error);
        }
    }

    // Cargar habitaciones
    async loadRooms() {
        try {
            // Simular carga de habitaciones desde Firebase
            this.rooms = [
                { id: 'room_101', number: '101', name: 'Habitación 101', type: 'STANDARD' },
                { id: 'room_103', number: '103', name: 'Habitación 103', type: 'STANDARD' },
                { id: 'room_105', number: '105', name: 'Habitación 105', type: 'MEDIUM' },
                { id: 'room_108', number: '108', name: 'Suite 108', type: 'SUITE' },
                { id: 'room_109', number: '109', name: 'Suite 109', type: 'SUITE' }
            ];
            
            this.populateRoomSelect();
        } catch (error) {
            console.error('Error al cargar habitaciones:', error);
        }
    }

    // Cargar especialidades quirúrgicas
    loadSurgicalSpecialties() {
        const specialties = getAllSpecialties();
        const specialtySelect = document.getElementById('specialtySelect');
        
        specialtySelect.innerHTML = '<option value="">Seleccionar especialidad</option>';
        
        specialties.forEach(specialty => {
            const option = document.createElement('option');
            option.value = specialty.id;
            option.textContent = specialty.name;
            specialtySelect.appendChild(option);
        });
    }

    // Función eliminada - ya no necesitamos poblar selector de pacientes

    // Poblar selector de habitaciones (solo disponibles)
    populateRoomSelect() {
        const roomSelect = document.getElementById('roomSelect');
        roomSelect.innerHTML = '<option value="">Pendiente de asignación</option>';
        
        // Filtrar solo habitaciones disponibles
        const availableRooms = this.rooms.filter(room => room.status === 'disponible');
        
        availableRooms.forEach(room => {
            const option = document.createElement('option');
            option.value = room.id;
            option.textContent = `${room.name} (${room.type}) - Disponible`;
            option.dataset.roomNumber = room.number;
            roomSelect.appendChild(option);
        });
    }

    // Inicializar calendario (SOLO CALENDARIO SIMPLE)
    initializeCalendar() {
        console.log('🔄 Iniciando inicialización de calendario...');
        console.log('📅 FullCalendar deshabilitado - usando calendario simple');
        
        // Crear directamente el calendario simple
        this.createSimpleCalendar();
    }

    // Crear calendario simple como alternativa
    createSimpleCalendar() {
        const calendarEl = document.getElementById('calendar');
        
        if (!calendarEl) {
            console.error('❌ Elemento calendar no encontrado');
            return;
        }
        
        console.log('🔄 Creando calendario simple...');
        
        const today = new Date();
        const currentMonth = today.getMonth();
        const currentYear = today.getFullYear();
        
        // Crear HTML del calendario simple
        const calendarHTML = `
            <div class="simple-calendar">
                <div class="calendar-header">
                    <button onclick="window.surgicalApp.previousMonth()" class="btn btn-sm">←</button>
                    <h4 id="calendarTitle">${this.getMonthName(currentMonth)} ${currentYear}</h4>
                    <button onclick="window.surgicalApp.nextMonth()" class="btn btn-sm">→</button>
                </div>
                <div class="calendar-grid" id="calendarGrid">
                    ${this.generateCalendarGrid(currentMonth, currentYear)}
                </div>
            </div>
        `;
        
        calendarEl.innerHTML = calendarHTML;
        console.log('✅ Calendario simple creado');
    }
    
    // Generar grid del calendario
    generateCalendarGrid(month, year) {
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const daysInMonth = lastDay.getDate();
        const startingDay = firstDay.getDay();
        
        let html = '<div class="calendar-weekdays"><div>Dom</div><div>Lun</div><div>Mar</div><div>Mié</div><div>Jue</div><div>Vie</div><div>Sáb</div></div>';
        html += '<div class="calendar-days">';
        
        // Días vacíos al inicio
        for (let i = 0; i < startingDay; i++) {
            html += '<div class="calendar-day empty"></div>';
        }
        
        // Días del mes
        for (let day = 1; day <= daysInMonth; day++) {
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            
            // Crear fecha sin problemas de zona horaria
            const dayDate = new Date(year, month, day);
            
            // Buscar eventos para este día
            const dayEvents = this.surgicalEvents.filter(event => {
                if (!event.startDateTime) return false;
                
                // Crear fecha del evento sin problemas de zona horaria
                const eventDateStr = event.startDateTime.split('T')[0]; // Obtener solo la parte de fecha
                const [eventYear, eventMonth, eventDay] = eventDateStr.split('-');
                const eventDate = new Date(parseInt(eventYear), parseInt(eventMonth) - 1, parseInt(eventDay));
                
                return eventDate.getFullYear() === dayDate.getFullYear() &&
                       eventDate.getMonth() === dayDate.getMonth() &&
                       eventDate.getDate() === dayDate.getDate();
            });
            
            const hasEvents = dayEvents.length > 0;
            
            if (hasEvents) {
                console.log(`📅 Día ${day} tiene ${dayEvents.length} evento(s):`, dayEvents.map(e => e.title));
            }
            
            html += `<div class="calendar-day ${hasEvents ? 'has-events' : ''}" onclick="window.surgicalApp.createSurgeryOnDate('${dateStr}')">
                <span class="day-number">${day}</span>
                ${hasEvents ? `<div class="event-indicator" title="${dayEvents.length} cirugía(s) programada(s)"></div>` : ''}
            </div>`;
        }
        
        html += '</div>';
        return html;
    }
    
    // Obtener nombre del mes
    getMonthName(month) {
        const months = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
                       'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
        return months[month];
    }
    
    // Actualizar calendario simple
    updateSimpleCalendar() {
        const calendarGrid = document.getElementById('calendarGrid');
        if (!calendarGrid) {
            console.log('⚠️ No se encontró calendarGrid');
            return;
        }
        
        console.log('🔄 Actualizando calendario simple...');
        console.log('📊 Eventos quirúrgicos actuales:', this.surgicalEvents.length);
        
        // Obtener el mes y año actual del título
        const titleElement = document.getElementById('calendarTitle');
        if (!titleElement) {
            console.log('⚠️ No se encontró calendarTitle');
            return;
        }
        
        const titleText = titleElement.textContent;
        const parts = titleText.split(' ');
        const monthName = parts[0];
        const year = parseInt(parts[1]);
        
        console.log('📅 Mes actual:', monthName, year);
        
        // Convertir nombre del mes a número
        const monthIndex = this.getMonthIndex(monthName);
        
        // Regenerar el grid con los eventos actualizados
        calendarGrid.innerHTML = this.generateCalendarGrid(monthIndex, year);
        
        console.log('✅ Calendario simple actualizado');
    }
    
    // Obtener índice del mes
    getMonthIndex(monthName) {
        const months = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
                       'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
        return months.indexOf(monthName);
    }
    
    // Navegación del calendario simple
    previousMonth() {
        const titleElement = document.getElementById('calendarTitle');
        if (!titleElement) return;
        
        const titleText = titleElement.textContent;
        const parts = titleText.split(' ');
        const monthName = parts[0];
        const year = parseInt(parts[1]);
        
        let monthIndex = this.getMonthIndex(monthName);
        let newYear = year;
        
        if (monthIndex === 0) {
            monthIndex = 11;
            newYear = year - 1;
        } else {
            monthIndex--;
        }
        
        titleElement.textContent = `${this.getMonthName(monthIndex)} ${newYear}`;
        
        const calendarGrid = document.getElementById('calendarGrid');
        if (calendarGrid) {
            calendarGrid.innerHTML = this.generateCalendarGrid(monthIndex, newYear);
        }
        
        console.log('Navegando al mes anterior:', this.getMonthName(monthIndex), newYear);
    }
    
    nextMonth() {
        const titleElement = document.getElementById('calendarTitle');
        if (!titleElement) return;
        
        const titleText = titleElement.textContent;
        const parts = titleText.split(' ');
        const monthName = parts[0];
        const year = parseInt(parts[1]);
        
        let monthIndex = this.getMonthIndex(monthName);
        let newYear = year;
        
        if (monthIndex === 11) {
            monthIndex = 0;
            newYear = year + 1;
        } else {
            monthIndex++;
        }
        
        titleElement.textContent = `${this.getMonthName(monthIndex)} ${newYear}`;
        
        const calendarGrid = document.getElementById('calendarGrid');
        if (calendarGrid) {
            calendarGrid.innerHTML = this.generateCalendarGrid(monthIndex, newYear);
        }
        
        console.log('Navegando al mes siguiente:', this.getMonthName(monthIndex), newYear);
    }

    // Configurar event listeners
    setupEventListeners() {
        // Formulario de cirugía
        document.getElementById('surgeryForm').addEventListener('submit', (e) => {
            e.preventDefault();
            // Prevenir doble envío
            if (this.isSaving) {
                console.log('Ya se está guardando una cirugía, espera...');
                return;
            }
            this.saveSurgeryEvent();
        });

        // Selector de especialidad (ya no actualiza procedimientos automáticamente)
        document.getElementById('specialtySelect').addEventListener('change', (e) => {
            // El usuario ahora escribe el procedimiento libremente
            console.log('Especialidad seleccionada:', e.target.value);
        });

        // Ya no necesitamos event listener para selector de paciente

        // Badges de prioridad
        document.querySelectorAll('.priority-badge').forEach(badge => {
            badge.addEventListener('click', (e) => {
                this.selectPriority(e.target);
            });
        });

        // Búsqueda
        document.getElementById('searchInput').addEventListener('input', (e) => {
            this.filterSurgicalEvents(e.target.value);
        });

        // Filtro de fecha
        document.getElementById('dateFilter').addEventListener('change', (e) => {
            this.filterByDate(e.target.value);
        });

        // Filtro de especialidad
        document.getElementById('specialtyFilter').addEventListener('change', (e) => {
            this.filterBySpecialty(e.target.value);
        });
    }

    // Actualizar procedimientos según especialidad (ya no se usa, pero mantenemos para compatibilidad)
    updateProceduresBySpecialty(specialtyId) {
        // Ya no necesitamos poblar un selector, el usuario escribe libremente
        console.log('Procedimiento será ingresado libremente por el usuario');
    }

    // Actualizar habitación según paciente
    // Función eliminada - ya no necesitamos actualizar habitación por paciente

    // Seleccionar prioridad
    selectPriority(selectedBadge) {
        document.querySelectorAll('.priority-badge').forEach(badge => {
            badge.classList.remove('selected');
        });
        selectedBadge.classList.add('selected');
    }

    // Mostrar modal de crear cirugía
    showCreateSurgeryModal() {
        this.currentEditingEvent = null;
        document.getElementById('modalTitle').textContent = 'Nueva Cirugía';
        document.getElementById('surgeryForm').reset();
        
        // Seleccionar prioridad normal por defecto
        document.querySelectorAll('.priority-badge').forEach(badge => {
            badge.classList.remove('selected');
        });
        document.querySelector('.priority-badge.normal').classList.add('selected');
        
        document.getElementById('surgeryModal').style.display = 'block';
    }

    // Crear cirugía en fecha específica
    createSurgeryOnDate(dateStr) {
        console.log('📅 Fecha seleccionada:', dateStr);
        
        this.showCreateSurgeryModal();
        
        // Crear fecha sin problemas de zona horaria
        // dateStr viene en formato "YYYY-MM-DD"
        const [year, month, day] = dateStr.split('-');
        const date = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
        
        console.log('📅 Fecha procesada:', date);
        console.log('📅 Año:', year, 'Mes:', month, 'Día:', day);
        
        // Establecer fecha y hora por defecto
        const startTime = new Date(date);
        startTime.setHours(8, 0, 0, 0);
        
        const endTime = new Date(date);
        endTime.setHours(10, 0, 0, 0);
        
        const startDateFormatted = this.formatDate(startTime);
        const startTimeFormatted = this.formatTime(startTime);
        const endDateFormatted = this.formatDate(endTime);
        const endTimeFormatted = this.formatTime(endTime);
        
        console.log('📅 Fecha de inicio:', startDateFormatted);
        console.log('⏰ Hora de inicio:', startTimeFormatted);
        console.log('📅 Fecha de fin:', endDateFormatted);
        console.log('⏰ Hora de fin:', endTimeFormatted);
        
        document.getElementById('startDate').value = startDateFormatted;
        document.getElementById('startTime').value = startTimeFormatted;
        document.getElementById('endDate').value = endDateFormatted;
        document.getElementById('endTime').value = endTimeFormatted;
    }

    // Editar evento de cirugía
    editSurgeryEvent(event) {
        const surgicalEvent = this.surgicalEvents.find(e => e.id === event.id);
        if (!surgicalEvent) return;
        
        this.currentEditingEvent = surgicalEvent;
        document.getElementById('modalTitle').textContent = 'Editar Cirugía';
        
        // Llenar formulario con datos del evento
        document.getElementById('surgeryTitle').value = surgicalEvent.title;
        document.getElementById('patientName').value = surgicalEvent.patientName || '';
        document.getElementById('patientDiagnosis').value = surgicalEvent.patientDiagnosis || '';
        document.getElementById('roomSelect').value = surgicalEvent.roomId || '';
        document.getElementById('specialtySelect').value = surgicalEvent.specialty;
        document.getElementById('procedureInput').value = surgicalEvent.procedure;
        const startDate = new Date(surgicalEvent.startDateTime);
        const endDate = new Date(surgicalEvent.endDateTime);
        
        document.getElementById('startDate').value = this.formatDate(startDate);
        document.getElementById('startTime').value = this.formatTime(startDate);
        document.getElementById('endDate').value = this.formatDate(endDate);
        document.getElementById('endTime').value = this.formatTime(endDate);
        document.getElementById('notes').value = surgicalEvent.notes;
        document.getElementById('preoperativeNotes').value = surgicalEvent.preoperativeNotes;
        
        // Seleccionar prioridad
        document.querySelectorAll('.priority-badge').forEach(badge => {
            badge.classList.remove('selected');
            if (badge.dataset.priority === surgicalEvent.priority) {
                badge.classList.add('selected');
            }
        });
        
        // Llenar equipo médico
        const team = surgicalEvent.medicalTeam;
        document.getElementById('treatingDoctor').value = team.treatingDoctor || '';
        document.getElementById('surgeon').value = team.surgeon || '';
        document.getElementById('assistant').value = team.assistant || '';
        document.getElementById('anesthesiologist').value = team.anesthesiologist || '';
        document.getElementById('instrumentNurse').value = team.instrumentNurse || '';
        document.getElementById('circulatingNurse').value = team.circulatingNurse || '';
        document.getElementById('scrubNurse').value = team.scrubNurse || '';
        
        document.getElementById('surgeryModal').style.display = 'block';
    }

    // Guardar evento de cirugía
    async saveSurgeryEvent() {
        try {
            console.log('🔄 Iniciando guardado de cirugía...');
            
            // Prevenir doble guardado
            if (this.isSaving) {
                console.log('⚠️ Ya se está guardando una cirugía, espera...');
                return;
            }
            
            this.isSaving = true;
            this.showLoading(true);
            console.log('✅ Bandera isSaving activada');
            
            // Deshabilitar botón de guardar
            const saveButton = document.querySelector('#surgeryForm button[type="submit"]');
            if (saveButton) {
                saveButton.disabled = true;
                saveButton.textContent = 'Guardando...';
                console.log('✅ Botón deshabilitado');
            }
            
            console.log('📝 Obteniendo datos del formulario...');
            const formData = this.getFormData();
            console.log('📝 Datos del formulario:', formData);
            
            const surgicalEvent = new SurgicalEvent(formData);
            console.log('📝 Evento quirúrgico creado:', surgicalEvent);
            
            // Validar datos
            console.log('🔍 Validando datos...');
            const errors = surgicalEvent.validate();
            if (errors.length > 0) {
                console.log('❌ Errores de validación:', errors);
                this.showAlert('Errores en el formulario: ' + errors.join(', '), 'error');
                this.isSaving = false;
                this.showLoading(false);
                
                // Rehabilitar botón de guardar
                const saveButton = document.querySelector('#surgeryForm button[type="submit"]');
                if (saveButton) {
                    saveButton.disabled = false;
                    saveButton.textContent = '💾 Guardar Cirugía';
                }
                return;
            }
            
            console.log('✅ Validación exitosa');
            
            // Crear o actualizar evento
            if (this.currentEditingEvent) {
                console.log('🔄 Actualizando evento existente...');
                surgicalEvent.id = this.currentEditingEvent.id;
                await this.updateSurgeryEvent(surgicalEvent);
            } else {
                console.log('🆕 Creando nuevo evento...');
                await this.createSurgeryEvent(surgicalEvent);
            }
            
            console.log('✅ Evento guardado exitosamente');
            this.closeSurgeryModal();
            this.showAlert('Cirugía guardada correctamente', 'success');
            
        } catch (error) {
            console.error('❌ Error al guardar cirugía:', error);
            this.showAlert('Error al guardar la cirugía: ' + error.message, 'error');
        } finally {
            console.log('🔄 Finalizando proceso de guardado...');
            this.isSaving = false;
            this.showLoading(false);
            
            // Rehabilitar botón de guardar
            const saveButton = document.querySelector('#surgeryForm button[type="submit"]');
            if (saveButton) {
                saveButton.disabled = false;
                saveButton.textContent = '💾 Guardar Cirugía';
            }
            console.log('✅ Proceso de guardado finalizado');
        }
    }

    // Obtener datos del formulario
    getFormData() {
        const selectedPriority = document.querySelector('.priority-badge.selected');
        const roomSelect = document.getElementById('roomSelect');
        const selectedRoomOption = roomSelect.options[roomSelect.selectedIndex];
        
        return {
            id: this.currentEditingEvent?.id,
            title: document.getElementById('surgeryTitle').value,
            patientName: document.getElementById('patientName').value,
            patientDiagnosis: document.getElementById('patientDiagnosis').value,
            roomId: roomSelect.value || null,
            roomNumber: selectedRoomOption?.dataset.roomNumber || null,
            startDateTime: this.combineDateTime(
                document.getElementById('startDate').value,
                document.getElementById('startTime').value
            ),
            endDateTime: this.combineDateTime(
                document.getElementById('endDate').value,
                document.getElementById('endTime').value
            ),
            specialty: document.getElementById('specialtySelect').value,
            procedure: document.getElementById('procedureInput').value,
            priority: selectedPriority?.dataset.priority || 'NORMAL',
            notes: document.getElementById('notes').value,
            preoperativeNotes: document.getElementById('preoperativeNotes').value,
            medicalTeam: {
                treatingDoctor: document.getElementById('treatingDoctor').value,
                surgeon: document.getElementById('surgeon').value,
                assistant: document.getElementById('assistant').value,
                anesthesiologist: document.getElementById('anesthesiologist').value,
                instrumentNurse: document.getElementById('instrumentNurse').value,
                circulatingNurse: document.getElementById('circulatingNurse').value,
                scrubNurse: document.getElementById('scrubNurse').value
            }
        };
    }

    // Crear evento de cirugía
    async createSurgeryEvent(surgicalEvent) {
        try {
            console.log('🔄 Creando evento de cirugía:', surgicalEvent);
            
            // Guardar localmente y en Google Calendar
            console.log('💾 Guardando evento localmente y en Google Calendar...');
            await this.saveSurgeryEventToFirebase(surgicalEvent);
            
            // Agregar a la lista local
            this.surgicalEvents.push(surgicalEvent);
            console.log('📝 Evento agregado a la lista local');
            
            // Guardar en localStorage
            this.saveToLocalStorage();
            
            // Crear paciente en gestión de cuartos si se asignó habitación
            console.log('🔍 Verificando asignación de habitación...');
            console.log('🔍 roomId:', surgicalEvent.roomId);
            console.log('🔍 roomId type:', typeof surgicalEvent.roomId);
            console.log('🔍 roomId !== "":', surgicalEvent.roomId !== '');
            console.log('🔍 roomId !== null:', surgicalEvent.roomId !== null);
            
            if (surgicalEvent.roomId && surgicalEvent.roomId !== '' && surgicalEvent.roomId !== null) {
                console.log('🏠 Creando paciente en gestión de cuartos...');
                await this.createPatientInRoomManagement(surgicalEvent);
                // NO crear paciente pendiente aquí para evitar duplicación
            } else {
                console.log('📝 Creando paciente pendiente de asignación...');
                await this.createPendingPatient(surgicalEvent);
            }
            
            // Actualizar calendario y lista
            this.updateCalendar();
            this.updateSurgeryList();
            
            console.log('✅ Evento de cirugía creado exitosamente');
            
        } catch (error) {
            console.error('❌ Error al crear evento de cirugía:', error);
            throw error;
        }
    }

    // Crear paciente en gestión de cuartos
    async createPatientInRoomManagement(surgicalEvent) {
        try {
            console.log('🏠 Creando paciente en gestión de cuartos:', surgicalEvent);
            
            // Obtener datos de cuartos desde localStorage
            const roomsData = localStorage.getItem('rooms');
            if (!roomsData) {
                console.log('⚠️ No hay datos de cuartos disponibles');
                return;
            }
            
            const rooms = JSON.parse(roomsData);
            const room = rooms.find(r => r.id === surgicalEvent.roomId);
            
            if (!room) {
                console.log('⚠️ Habitación no encontrada:', surgicalEvent.roomId);
                return;
            }
            
            // Actualizar la habitación con los datos del paciente
            room.status = 'OCCUPIED';
            room.patientName = surgicalEvent.patientName;
            room.patientDiagnosis = surgicalEvent.patientDiagnosis;
            room.patientDoctor = surgicalEvent.medicalTeam.treatingDoctor || surgicalEvent.medicalTeam.surgeon;
            room.assignedAt = new Date().toISOString();
            room.assignedBy = 'Programación Quirúrgica';
            room.updatedAt = new Date().toISOString();
            
            // Guardar cuartos actualizados
            localStorage.setItem('rooms', JSON.stringify(rooms));
            
            console.log('✅ Paciente creado en gestión de cuartos:', {
                room: room.number,
                patient: surgicalEvent.patientName,
                diagnosis: surgicalEvent.patientDiagnosis
            });
            
            // NO crear paciente pendiente aquí para evitar duplicación
            // El paciente ya está en gestión de cuartos, no necesita estar en pacientes pendientes
            console.log('✅ Paciente creado solo en gestión de cuartos (sin duplicación)');
            
            // Mostrar mensaje de éxito
            this.showAlert(`✅ Paciente ${surgicalEvent.patientName} asignado a habitación ${room.number}`, 'success');
            
        } catch (error) {
            console.error('❌ Error al crear paciente en gestión de cuartos:', error);
            this.showAlert('⚠️ Error al asignar habitación, pero la cirugía se guardó correctamente', 'warning');
        }
    }

    // Crear paciente pendiente de asignación
    async createPendingPatient(surgicalEvent) {
        try {
            console.log('📝 Creando paciente pendiente:', surgicalEvent);
            
            // Verificar autenticación antes de proceder
            const currentUser = firebase.auth().currentUser;
            if (!currentUser) {
                console.error('❌ Usuario no autenticado, no se puede crear paciente pendiente');
                this.showAlert('❌ Debes estar autenticado para crear pacientes', 'error');
                return;
            }
            
            console.log('✅ Usuario autenticado:', currentUser.uid);
            
            // Crear nuevo paciente pendiente
            const pendingPatient = {
                id: 'pending_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
                name: surgicalEvent.patientName || 'Sin nombre',
                diagnosis: surgicalEvent.patientDiagnosis || 'Sin diagnóstico',
                doctor: surgicalEvent.medicalTeam.treatingDoctor || surgicalEvent.medicalTeam.surgeon,
                surgeryId: surgicalEvent.id,
                surgeryTitle: surgicalEvent.title,
                surgeryDate: surgicalEvent.startDateTime,
                specialty: surgicalEvent.specialty,
                procedure: surgicalEvent.procedure,
                priority: surgicalEvent.priority,
                status: 'PENDIENTE_ASIGNACION',
                createdAt: new Date().toISOString(),
                createdBy: 'Programación Quirúrgica',
                // Campos adicionales para completar desde Gestión de Pacientes
                age: '',
                sex: '',
                phone: '',
                address: '',
                emergencyContact: '',
                emergencyPhone: '',
                allergies: '',
                medications: '',
                notes: '',
                bloodType: '',
                weight: '',
                height: '',
                roomId: null,
                roomNumber: null,
                assignedAt: null,
                assignedBy: null,
                // Contador de días de estancia intrahospitalaria
                daysOfStay: 0,
                roomAssignedAt: null
            };
            
            console.log('📝 Paciente pendiente creado:', pendingPatient);
            
            // Guardar en Firebase Realtime Database
            console.log('🔥 Llamando a savePendingPatientToFirebase...');
            await this.savePendingPatientToFirebase(pendingPatient);
            console.log('🔥 savePendingPatientToFirebase completado');
            
            console.log('✅ Paciente pendiente creado:', {
                id: pendingPatient.id,
                name: surgicalEvent.patientName,
                diagnosis: surgicalEvent.patientDiagnosis
            });
            
            // Mostrar mensaje informativo
            this.showAlert(`📝 Paciente ${surgicalEvent.patientName} creado. Puede asignar habitación desde Gestión de Pacientes`, 'info');
            
            console.log('✅ Función createPendingPatient completada exitosamente');
            
        } catch (error) {
            console.error('❌ Error al crear paciente pendiente:', error);
            console.error('❌ Stack trace:', error.stack);
            this.showAlert('⚠️ Error al crear paciente pendiente, pero la cirugía se guardó correctamente', 'warning');
        }
    }

    // Guardar paciente pendiente en Firebase
    async savePendingPatientToFirebase(pendingPatient) {
        try {
            console.log('🔥 Guardando paciente pendiente en Firebase...');
            
            // Verificar que Firebase esté disponible
            if (typeof firebase === 'undefined') {
                throw new Error('Firebase no está disponible');
            }
            
            console.log('🔥 Firebase disponible, obteniendo referencia a la base de datos...');
            
            // Obtener referencia a la base de datos
            const database = firebase.database();
            
            // Esperar a que el usuario esté autenticado
            const currentUser = firebase.auth().currentUser;
            if (!currentUser) {
                console.log('⏳ Usuario no autenticado, esperando autenticación...');
                
                // Esperar a que el usuario se autentique
                return new Promise((resolve, reject) => {
                    const unsubscribe = firebase.auth().onAuthStateChanged((user) => {
                        unsubscribe();
                        if (user) {
                            console.log('✅ Usuario autenticado, continuando con el guardado...');
                            this.savePendingPatientToFirebase(pendingPatient).then(resolve).catch(reject);
                        } else {
                            console.log('❌ Usuario no se pudo autenticar');
                            reject(new Error('Usuario no autenticado'));
                        }
                    });
                });
            }
            
            console.log('🔥 Usuario autenticado:', currentUser.uid);
            
            // Guardar en la ruta global (más limpio)
            const pendingPatientsRef = database.ref('pendingPatients');
            
            console.log('🔥 Guardando en Firebase...');
            console.log('🔥 Datos del paciente a guardar:', JSON.stringify(pendingPatient, null, 2));
            
            // Verificar que los nuevos campos estén presentes
            console.log('🔍 Verificando campos de días de estancia:');
            console.log('🔍 daysOfStay:', pendingPatient.daysOfStay);
            console.log('🔍 roomAssignedAt:', pendingPatient.roomAssignedAt);
            
            // Guardar el paciente pendiente
            console.log('🔥 Ejecutando set() en Firebase...');
            await pendingPatientsRef.child(pendingPatient.id).set(pendingPatient);
            
            console.log('✅ Paciente pendiente guardado en Firebase exitosamente');
            console.log('✅ ID del paciente guardado:', pendingPatient.id);
            
            // Verificar que se guardó correctamente
            const verificationRef = database.ref(`pendingPatients/${pendingPatient.id}`);
            const snapshot = await verificationRef.once('value');
            if (snapshot.exists()) {
                console.log('✅ Verificación exitosa: Paciente existe en Firebase');
                console.log('✅ Datos verificados:', snapshot.val());
            } else {
                console.error('❌ Verificación fallida: Paciente no existe en Firebase');
            }
            
        } catch (error) {
            console.error('❌ Error al guardar paciente pendiente en Firebase:', error);
            throw error;
        }
    }

    // Exportar pacientes pendientes
    exportPendingPatients() {
        console.log('🔄 Método exportPendingPatients de la clase llamado');
        try {
            const pendingPatientsData = localStorage.getItem('pendingPatients');
            console.log('📝 Datos de pacientes pendientes:', pendingPatientsData);
            if (!pendingPatientsData) {
                this.showAlert('❌ No hay pacientes pendientes para exportar', 'error');
                return;
            }

            const pendingPatients = JSON.parse(pendingPatientsData);
            console.log('📊 Pacientes pendientes parseados:', pendingPatients.length);
            if (pendingPatients.length === 0) {
                console.log('❌ No hay pacientes pendientes para exportar');
                this.showAlert('❌ No hay pacientes pendientes para exportar', 'error');
                return;
            }

            // Crear un código que se pueda copiar y pegar
            console.log('📝 Creando código de exportación...');
            const exportCode = `// Copia este código y pégalo en la consola de Gestión de Pacientes
const pendingPatientsData = '${pendingPatientsData.replace(/'/g, "\\'")}';
localStorage.setItem('pendingPatients', pendingPatientsData);
console.log('✅ Pacientes pendientes importados:', JSON.parse(pendingPatientsData).length);
alert('✅ Pacientes pendientes importados exitosamente');`;
            console.log('✅ Código de exportación creado');

            // Mostrar el código en un modal
            console.log('🖼️ Creando modal...');
            const modal = document.createElement('div');
            modal.className = 'modal';
            modal.innerHTML = `
                <div class="modal-content" style="max-width: 800px;">
                    <div class="modal-header">
                        <h3>📤 Exportar Pacientes Pendientes</h3>
                        <span class="close" onclick="closeModal()">&times;</span>
                    </div>
                    <div class="modal-body">
                        <p><strong>Pacientes pendientes encontrados:</strong> ${pendingPatients.length}</p>
                        <p><strong>Instrucciones:</strong></p>
                        <ol>
                            <li>Ve a la página de Gestión de Pacientes</li>
                            <li>Abre la consola del navegador (F12)</li>
                            <li>Copia y pega el código de abajo</li>
                            <li>Presiona Enter</li>
                        </ol>
                        <textarea readonly style="width: 100%; height: 200px; font-family: monospace; font-size: 12px;">${exportCode}</textarea>
                        <button class="btn" onclick="copyToClipboard()">
                            📋 Copiar Código
                        </button>
                    </div>
                </div>
            `;
            console.log('📄 Modal HTML creado, agregando al DOM...');
            document.body.appendChild(modal);
            console.log('✅ Modal agregado al DOM');
            
            // Hacer visible el modal
            modal.style.display = 'block';
            console.log('👁️ Modal hecho visible');
            
            console.log('🔍 Modal creado:', modal);
            console.log('🔍 Modal visible:', modal.style.display);
            console.log('🔍 Modal classList:', modal.classList);

            // Función para copiar al portapapeles
            window.copyToClipboard = () => {
                const textarea = modal.querySelector('textarea');
                const text = textarea.value;
                
                navigator.clipboard.writeText(text).then(() => {
                    this.showAlert('✅ Código copiado al portapapeles', 'success');
                }).catch(() => {
                    this.showAlert('❌ Error al copiar al portapapeles', 'error');
                });
            };

        } catch (error) {
            console.error('❌ Error al exportar pacientes pendientes:', error);
            this.showAlert('❌ Error al exportar pacientes pendientes', 'error');
        }
    }

    // Actualizar evento de cirugía
    async updateSurgeryEvent(surgicalEvent) {
        try {
            // Actualizar en Google Calendar si está autenticado
            if (this.googleCalendarIntegration.isAuthenticated() && surgicalEvent.googleCalendarEventId) {
                await this.googleCalendarIntegration.updateSurgeryEvent(surgicalEvent);
            }
            
            // Actualizar en Firebase
            await this.updateSurgeryEventInFirebase(surgicalEvent);
            
            // Actualizar en la lista local
            const index = this.surgicalEvents.findIndex(e => e.id === surgicalEvent.id);
            if (index !== -1) {
                this.surgicalEvents[index] = surgicalEvent;
            }
            
            // Guardar en localStorage
            this.saveToLocalStorage();
            
            // Actualizar calendario y lista
            this.updateCalendar();
            this.updateSurgeryList();
            
        } catch (error) {
            console.error('Error al actualizar evento de cirugía:', error);
            throw error;
        }
    }

    // Cerrar modal de cirugía
    closeSurgeryModal() {
        document.getElementById('surgeryModal').style.display = 'none';
        this.currentEditingEvent = null;
    }

    // Sincronizar con Google Calendar
    async syncWithGoogleCalendar() {
        try {
            this.showLoading(true);
            
            // Verificar que la API esté inicializada
            if (!this.googleCalendarIntegration.isInitialized) {
                console.log('Inicializando Google Calendar API...');
                const initialized = await this.googleCalendarIntegration.initialize();
                if (!initialized) {
                    throw new Error('No se pudo inicializar Google Calendar API');
                }
            }
            
            // Verificar autenticación
            if (!this.googleCalendarIntegration.isAuthenticated()) {
                console.log('Autenticando usuario...');
                await this.googleCalendarIntegration.authenticate();
            }
            
            console.log('Sincronizando eventos desde Google Calendar...');
            await this.syncEventsFromGoogleCalendar();
            
            // Actualizar interfaz después de sincronizar
            this.updateCalendar();
            this.updateSurgeryList();
            
            this.showAlert('✅ Sincronización completada', 'success');
            
        } catch (error) {
            console.error('Error en sincronización:', error);
            this.showAlert(`❌ Error en la sincronización: ${error.message}`, 'error');
        } finally {
            this.showLoading(false);
        }
    }

    // Intentar sincronización automática al cargar la página
    async attemptAutoSync() {
        try {
            console.log('🔄 Intentando sincronización automática con Google Calendar...');
            
            // Esperar un poco para que la API se inicialice completamente
            setTimeout(async () => {
                try {
                    // Verificar si ya está autenticado
                    if (this.googleCalendarIntegration.isAuthenticated()) {
                        console.log('✅ Usuario ya autenticado, sincronizando...');
                        await this.syncEventsFromGoogleCalendar();
                        this.updateCalendar();
                        this.updateSurgeryList();
                        console.log('✅ Sincronización automática completada');
                    } else {
                        console.log('🔐 Usuario no autenticado, intentando autenticación automática...');
                        
                        // Intentar autenticación automática
                        try {
                            await this.googleCalendarIntegration.authenticate();
                            console.log('✅ Autenticación automática exitosa');
                            
                            // Sincronizar después de autenticar
                            await this.syncEventsFromGoogleCalendar();
                            this.updateCalendar();
                            this.updateSurgeryList();
                            console.log('✅ Sincronización automática completada después de autenticación');
                            
                        } catch (authError) {
                            console.log('⚠️ Autenticación automática falló:', authError.message);
                            
                            // Si es un error de popup bloqueado, mostrar mensaje específico
                            if (authError.message.includes('popup') || authError.message.includes('blocked')) {
                                console.log('🔧 Popup bloqueado, el sistema usará redirección automáticamente');
                                this.showAlert('⚠️ Ventanas emergentes bloqueadas. El sistema usará redirección automáticamente.', 'info');
                            } else {
                                console.log('🔍 Error de autenticación:', authError.message);
                                this.showAlert('⚠️ Para sincronizar con Google Calendar, haz clic en "Sincronizar"', 'info');
                            }
                        }
                    }
                } catch (error) {
                    console.log('⚠️ Error en sincronización automática:', error.message);
                }
            }, 2000); // Esperar 2 segundos
            
        } catch (error) {
            console.log('⚠️ Error al intentar sincronización automática:', error.message);
        }
    }

    // Iniciar sincronización automática
    startAutoSync() {
        // Sincronizar cada 5 minutos si el usuario está autenticado
        setInterval(async () => {
            if (this.googleCalendarIntegration.isAuthenticated()) {
                try {
                    console.log('🔄 Sincronización automática...');
                    await this.syncEventsFromGoogleCalendar();
                    this.updateCalendar();
                    this.updateSurgeryList();
                } catch (error) {
                    console.log('Error en sincronización automática:', error);
                }
            }
        }, 5 * 60 * 1000); // 5 minutos
        
        console.log('✅ Sincronización automática iniciada (cada 5 minutos)');
    }

    // Sincronizar eventos desde Google Calendar
    async syncEventsFromGoogleCalendar() {
        try {
            if (!this.googleCalendarIntegration.isAuthenticated()) {
                console.log('⚠️ Usuario no autenticado, no se puede sincronizar');
                return;
            }
            
            console.log('🔄 Obteniendo eventos desde Google Calendar...');
            
            // Obtener eventos de los últimos 6 meses y próximos 12 meses
            const now = new Date();
            const sixMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 6, 1);
            const twelveMonthsFromNow = new Date(now.getFullYear(), now.getMonth() + 12, 31);
            
            const startDate = sixMonthsAgo.toISOString();
            const endDate = twelveMonthsFromNow.toISOString();
            
            console.log('📅 Fecha actual:', now.toISOString());
            console.log('📅 Fecha actual (local):', now.toLocaleDateString());
            console.log('📅 6 meses atrás:', sixMonthsAgo.toISOString());
            console.log('📅 6 meses atrás (local):', sixMonthsAgo.toLocaleDateString());
            console.log('📅 12 meses adelante:', twelveMonthsFromNow.toISOString());
            console.log('📅 12 meses adelante (local):', twelveMonthsFromNow.toLocaleDateString());
            console.log('📅 Buscando eventos desde:', startDate);
            console.log('📅 Buscando eventos hasta:', endDate);
            
            const googleEvents = await this.googleCalendarIntegration.getSurgeryEvents(startDate, endDate);
            console.log('📅 Eventos obtenidos de Google Calendar:', googleEvents.length);
            
            // Convertir eventos de Google Calendar a formato local
            const syncedEvents = googleEvents.map(googleEvent => {
                // Extraer información del título y descripción
                const title = googleEvent.summary || 'Cirugía';
                const description = googleEvent.description || '';
                
                // Parsear información del paciente y otros datos de la descripción
                const lines = description.split('\n');
                let patientName = 'Paciente no especificado';
                let specialty = 'No especificada';
                let procedure = 'No especificado';
                let roomNumber = 'No especificada';
                let priority = 'MEDIA';
                
                lines.forEach(line => {
                    if (line.includes('Paciente:')) {
                        patientName = line.replace('Paciente:', '').trim();
                    } else if (line.includes('Especialidad:')) {
                        specialty = line.replace('Especialidad:', '').trim();
                    } else if (line.includes('Procedimiento:')) {
                        procedure = line.replace('Procedimiento:', '').trim();
                    } else if (line.includes('Habitación:')) {
                        roomNumber = line.replace('Habitación:', '').trim();
                    } else if (line.includes('Prioridad:')) {
                        priority = line.replace('Prioridad:', '').trim();
                    }
                });
                
                // Si no se encontró información específica, usar el título como procedimiento
                if (procedure === 'No especificado' && title !== 'Cirugía') {
                    procedure = title;
                }
                
                return {
                    id: googleEvent.id || 'google_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
                    title: title,
                    patientName: patientName,
                    startDateTime: googleEvent.start?.dateTime || googleEvent.start?.date,
                    endDateTime: googleEvent.end?.dateTime || googleEvent.end?.date,
                    specialty: specialty,
                    procedure: procedure,
                    roomNumber: roomNumber,
                    status: 'PROGRAMADA',
                    priority: priority,
                    googleCalendarEventId: googleEvent.id,
                    createdAt: googleEvent.created || new Date().toISOString(),
                    updatedAt: googleEvent.updated || new Date().toISOString()
                };
            });
            
            console.log('🔄 Actualizando eventos locales con los de Google Calendar...');
            console.log('📊 Eventos locales antes:', this.surgicalEvents.length);
            console.log('📊 Eventos de Google Calendar:', syncedEvents.length);
            
            // Reemplazar completamente los eventos locales con los de Google Calendar
            this.surgicalEvents = syncedEvents;
            
            // Guardar en localStorage
            this.saveToLocalStorage();
            
            console.log('✅ Sincronizados', syncedEvents.length, 'eventos desde Google Calendar');
            console.log('📊 Eventos locales después:', this.surgicalEvents.length);
            
        } catch (error) {
            console.error('❌ Error sincronizando desde Google Calendar:', error);
            throw error;
        }
    }

    // Cargar eventos quirúrgicos
    async loadSurgicalEvents() {
        try {
            // Cargar cirugías desde localStorage (persistencia local)
            const savedEvents = localStorage.getItem('surgicalEvents');
            
            if (savedEvents) {
                this.surgicalEvents = JSON.parse(savedEvents);
            } else {
                this.surgicalEvents = [];
            }
            
            console.log('✅ Cirugías cargadas desde localStorage:', this.surgicalEvents.length);
            
            this.updateCalendar();
            this.updateSurgeryList();
            
        } catch (error) {
            console.error('Error al cargar eventos quirúrgicos:', error);
            // En caso de error, inicializar con array vacío
            this.surgicalEvents = [];
            this.updateCalendar();
            this.updateSurgeryList();
        }
    }

    // Actualizar calendario
    updateCalendar() {
        if (this.calendar) {
            // Si es FullCalendar
            this.calendar.removeAllEvents();
            this.calendar.addEventSource(this.surgicalEvents.map(event => ({
                id: event.id,
                title: event.title,
                start: event.startDateTime,
                end: event.endDateTime,
                backgroundColor: this.getEventColor(event.priority),
                borderColor: this.getEventColor(event.priority),
                extendedProps: event
            })));
        } else {
            // Si es calendario simple, actualizar el grid
            this.updateSimpleCalendar();
        }
    }

    // Obtener color del evento según prioridad
    getEventColor(priority) {
        const colors = {
            'URGENTE': '#e74c3c',
            'ALTA': '#f39c12',
            'NORMAL': '#27ae60',
            'BAJA': '#95a5a6'
        };
        return colors[priority] || '#27ae60';
    }

    // Personalizar visualización del evento
    customizeEventDisplay(info) {
        const event = info.event;
        const surgicalEvent = event.extendedProps;
        
        // Agregar tooltip con información adicional
        info.el.title = `${surgicalEvent.patientName} - ${surgicalEvent.procedure}\nHabitación: ${surgicalEvent.roomNumber}`;
        
        // Agregar icono según especialidad
        const specialtyIcon = this.getSpecialtyIcon(surgicalEvent.specialty);
        if (specialtyIcon) {
            info.el.innerHTML = `${specialtyIcon} ${event.title}`;
        }
    }

    // Obtener icono de especialidad
    getSpecialtyIcon(specialty) {
        const icons = {
            'GENERAL_SURGERY': '🔪',
            'GYNECOLOGY': '👩‍⚕️',
            'TRAUMATOLOGY_ORTHOPEDICS': '🦴',
            'OPHTHALMOLOGY': '👁️',
            'PLASTIC_SURGERY': '✨',
            'NEUROSURGERY': '🧠',
            'CARDIOVASCULAR_SURGERY': '❤️',
            'THORACIC_SURGERY': '🫁',
            'UROLOGY': '🔬',
            'PEDIATRIC_SURGERY': '👶',
            'ONCOLOGY_SURGERY': '🎗️',
            'VASCULAR_SURGERY': '🩸',
            'OTOLARYNGOLOGY': '👂',
            'MAXILLOFACIAL_SURGERY': '🦷'
        };
        return icons[specialty] || '🏥';
    }

    // Actualizar lista de cirugías
    updateSurgeryList() {
        const surgeryList = document.getElementById('surgeryList');
        surgeryList.innerHTML = '';
        
        // Crear controles de navegación
        const navigationControls = document.createElement('div');
        navigationControls.className = 'surgery-navigation';
        navigationControls.innerHTML = `
            <div class="navigation-header">
                <button class="nav-btn" onclick="window.surgicalApp.previousDay()">←</button>
                <span class="current-date">${this.formatDisplayDate(this.currentDisplayDate)}</span>
                <button class="nav-btn" onclick="window.surgicalApp.nextDay()">→</button>
            </div>
            <div class="navigation-actions">
                <button class="today-btn" onclick="window.surgicalApp.goToToday()">📅 Hoy</button>
            </div>
            <div class="navigation-info">
                <small>📅 Mostrando cirugías del día seleccionado</small>
            </div>
        `;
        surgeryList.appendChild(navigationControls);
        
        // Filtrar eventos por la fecha seleccionada
        const eventsForDate = this.getEventsForDate(this.currentDisplayDate);
        
        if (eventsForDate.length === 0) {
            const noEventsDiv = document.createElement('div');
            noEventsDiv.className = 'no-events-message';
            noEventsDiv.innerHTML = `
                <div style="text-align: center; padding: 20px; color: #7f8c8d;">
                    <p>📅 No hay cirugías programadas para ${this.formatDisplayDate(this.currentDisplayDate)}</p>
                    <p style="font-size: 14px;">Usa las flechas para navegar entre días</p>
                </div>
            `;
            surgeryList.appendChild(noEventsDiv);
            return;
        }
        
        // Mostrar eventos del día seleccionado
        eventsForDate.forEach(event => {
            const surgeryItem = document.createElement('div');
            surgeryItem.className = 'surgery-item';
            surgeryItem.innerHTML = `
                <div class="surgery-content" style="flex: 1;">
                    <h4>${event.title}</h4>
                    <div class="patient-info">👤 ${event.patientName}</div>
                    <div class="time-info">⏰ ${this.formatDateTime(event.startDateTime)} - ${this.formatDateTime(event.endDateTime)}</div>
                    <div class="status-badge status-${event.status.toLowerCase().replace('_', '-')}">${event.status}</div>
                </div>
                <div class="surgery-actions" style="display: flex; gap: 8px; align-items: center;">
                    <button class="btn-delete" onclick="event.stopPropagation(); window.surgicalApp.deleteSurgeryEvent('${event.id}')" 
                            style="background: #e74c3c; color: white; border: none; padding: 6px 10px; border-radius: 4px; cursor: pointer; font-size: 12px;"
                            title="Eliminar cirugía">
                        🗑️
                    </button>
                </div>
            `;
            
            // Hacer que el contenido sea clickeable para editar
            const surgeryContent = surgeryItem.querySelector('.surgery-content');
            surgeryContent.addEventListener('click', () => {
                this.editSurgeryEvent({ id: event.id });
            });
            
            surgeryList.appendChild(surgeryItem);
        });
    }

    // Eliminar evento de cirugía
    async deleteSurgeryEvent(eventId) {
        console.log('🗑️ Eliminando cirugía:', eventId);
        
        // Confirmar eliminación
        const confirmed = confirm('¿Estás seguro de que quieres eliminar esta cirugía? Esta acción no se puede deshacer.');
        if (!confirmed) {
            console.log('❌ Eliminación cancelada por el usuario');
            return;
        }
        
        try {
            // Buscar el evento
            const eventIndex = this.surgicalEvents.findIndex(event => event.id === eventId);
            if (eventIndex === -1) {
                console.error('❌ Evento no encontrado:', eventId);
                alert('Error: No se pudo encontrar la cirugía a eliminar');
                return;
            }
            
            const event = this.surgicalEvents[eventIndex];
            console.log('🔍 Evento encontrado:', event);
            console.log('🔍 googleCalendarEventId del evento:', event.googleCalendarEventId);
            console.log('🔍 ¿Tiene googleCalendarEventId?', !!event.googleCalendarEventId);
            
            // Verificar estado de autenticación de Google Calendar
            console.log('🔍 Estado de autenticación de Google Calendar:', this.googleCalendarIntegration.isAuthenticatedFlag);
            
            // Eliminar del Google Calendar si tiene eventId
            if (event.googleCalendarEventId) {
                console.log('🗑️ Eliminando del Google Calendar:', event.googleCalendarEventId);
                try {
                    await this.googleCalendarIntegration.deleteEvent(event.googleCalendarEventId);
                    console.log('✅ Evento eliminado del Google Calendar');
                    console.log('✅ DESPUÉS de Google Calendar, continuando...');
                } catch (error) {
                    console.error('❌ Error al eliminar del Google Calendar:', error);
                    console.error('❌ Stack trace del error:', error.stack);
                    // Continuar con la eliminación local aunque falle Google Calendar
                }
            } else {
                console.log('⚠️ El evento no tiene googleCalendarEventId, solo se eliminará localmente');
            }
            
            console.log('🔄 CONTINUANDO DESPUÉS DE GOOGLE CALENDAR...');
            
            // NUEVA FUNCIONALIDAD: Liberar cuarto si el paciente tenía uno asignado
            if (event.roomId && event.roomId !== '' && event.roomId !== null) {
                console.log('🏠 Liberando cuarto asignado:', event.roomId);
                try {
                    await this.liberateRoom(event.roomId, event.patientName);
                    console.log('✅ Cuarto liberado exitosamente');
                } catch (error) {
                    console.error('❌ Error al liberar cuarto:', error);
                    // Continuar con la eliminación aunque falle la liberación del cuarto
                }
            } else {
                console.log('🏠 No hay cuarto asignado para liberar');
            }
            
            // Eliminar del array local
            this.surgicalEvents.splice(eventIndex, 1);
            console.log('✅ Evento eliminado del array local');
            
            // Guardar en localStorage
            localStorage.setItem('surgicalEvents', JSON.stringify(this.surgicalEvents));
            console.log('✅ Evento eliminado del localStorage');
            
            // Guardar en Firebase
            console.log('🔥 Guardando cambios en Firebase...');
            console.log('🔥 ANTES de llamar a saveSurgicalEventsToFirebase...');
            try {
                await this.saveSurgicalEventsToFirebase();
                console.log('✅ Evento eliminado de Firebase');
                console.log('✅ DESPUÉS de saveSurgicalEventsToFirebase, continuando...');
            } catch (error) {
                console.error('❌ Error al guardar en Firebase:', error);
                console.error('❌ Stack trace del error:', error.stack);
                throw error; // Re-lanzar el error para que se maneje arriba
            }
            
            console.log('🔄 CONTINUANDO CON ELIMINACIÓN DE PACIENTE PENDIENTE...');
            
            // NUEVA FUNCIONALIDAD: Eliminar paciente pendiente si existe
            // Buscar por surgeryId ya que patientId puede estar vacío
            console.log('👤 Buscando paciente pendiente por surgeryId:', event.id);
            console.log('👤 Llamando a deletePendingPatientBySurgeryId...');
            try {
                await this.deletePendingPatientBySurgeryId(event.id);
                console.log('✅ deletePendingPatientBySurgeryId completado');
            } catch (error) {
                console.error('❌ Error en deletePendingPatientBySurgeryId:', error);
            }
            
            // Actualizar la lista
            this.updateSurgeryList();
            this.updateSimpleCalendar();
            
            // Mostrar mensaje de éxito
            alert('✅ Cirugía eliminada exitosamente');
            
        } catch (error) {
            console.error('❌ Error al eliminar cirugía:', error);
            alert('❌ Error al eliminar la cirugía. Inténtalo de nuevo.');
        }
    }

    // Obtener eventos para una fecha específica
    getEventsForDate(date) {
        const targetDate = new Date(date);
        targetDate.setHours(0, 0, 0, 0);
        
        return this.surgicalEvents.filter(event => {
            if (!event.startDateTime) return false;
            
            const eventDate = new Date(event.startDateTime);
            eventDate.setHours(0, 0, 0, 0);
            
            return eventDate.getTime() === targetDate.getTime();
        });
    }

    // Formatear fecha para mostrar
    formatDisplayDate(date) {
        const options = { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
        };
        return date.toLocaleDateString('es-ES', options);
    }

    // Navegar al día anterior
    previousDay() {
        this.currentDisplayDate.setDate(this.currentDisplayDate.getDate() - 1);
        this.updateSurgeryList();
    }

    // Navegar al día siguiente
    nextDay() {
        this.currentDisplayDate.setDate(this.currentDisplayDate.getDate() + 1);
        this.updateSurgeryList();
    }

    // Ir al día actual
    goToToday() {
        this.currentDisplayDate = new Date();
        this.updateSurgeryList();
    }

    // Filtrar eventos quirúrgicos
    filterSurgicalEvents(query) {
        const filteredEvents = this.surgicalEvents.filter(event => 
            event.title.toLowerCase().includes(query.toLowerCase()) ||
            event.patientName.toLowerCase().includes(query.toLowerCase()) ||
            event.procedure.toLowerCase().includes(query.toLowerCase())
        );
        
        this.updateSurgeryListWithEvents(filteredEvents);
    }

    // Filtrar por fecha
    filterByDate(date) {
        if (!date) {
            this.updateSurgeryList();
            return;
        }
        
        const filteredEvents = this.surgicalEvents.filter(event => {
            const eventDate = new Date(event.startDateTime).toDateString();
            const filterDate = new Date(date).toDateString();
            return eventDate === filterDate;
        });
        
        this.updateSurgeryListWithEvents(filteredEvents);
    }

    // Filtrar por especialidad
    filterBySpecialty(specialty) {
        if (!specialty) {
            this.updateSurgeryList();
            return;
        }
        
        const filteredEvents = this.surgicalEvents.filter(event => event.specialty === specialty);
        this.updateSurgeryListWithEvents(filteredEvents);
    }

    // Actualizar lista con eventos específicos
    updateSurgeryListWithEvents(events) {
        const surgeryList = document.getElementById('surgeryList');
        surgeryList.innerHTML = '';
        
        events.forEach(event => {
            const surgeryItem = document.createElement('div');
            surgeryItem.className = 'surgery-item';
            surgeryItem.innerHTML = `
                <h4>${event.title}</h4>
                <div class="patient-info">👤 ${event.patientName}</div>
                <div class="time-info">⏰ ${this.formatDateTime(event.startDateTime)} - ${this.formatDateTime(event.endDateTime)}</div>
                <div class="status-badge status-${event.status.toLowerCase().replace('_', '-')}">${event.status}</div>
            `;
            
            surgeryItem.addEventListener('click', () => {
                this.editSurgeryEvent({ id: event.id });
            });
            
            surgeryList.appendChild(surgeryItem);
        });
    }

    // Exportar programación
    exportSchedule() {
        const data = this.surgicalEvents.map(event => ({
            'Título': event.title,
            'Paciente': event.patientName,
            'Fecha Inicio': this.formatDateTime(event.startDateTime),
            'Fecha Fin': this.formatDateTime(event.endDateTime),
            'Especialidad': event.specialty,
            'Procedimiento': event.procedure,
            'Prioridad': event.priority,
            'Estado': event.status,
            'Habitación': event.roomNumber,
            'Cirujano': event.medicalTeam.surgeon,
            'Anestesiólogo': event.medicalTeam.anesthesiologist
        }));
        
        const csv = this.convertToCSV(data);
        this.downloadCSV(csv, 'programacion_quirurgica.csv');
    }

    // Convertir a CSV
    convertToCSV(data) {
        const headers = Object.keys(data[0]);
        const csvContent = [
            headers.join(','),
            ...data.map(row => headers.map(header => `"${row[header]}"`).join(','))
        ].join('\n');
        
        return csvContent;
    }

    // Descargar CSV
    downloadCSV(csv, filename) {
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    // Mostrar loading
    showLoading(show) {
        const loadingOverlay = document.getElementById('loadingOverlay');
        if (show) {
            loadingOverlay.classList.add('show');
        } else {
            loadingOverlay.classList.remove('show');
        }
    }

    // Mostrar alerta
    showAlert(message, type = 'info') {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type}`;
        alertDiv.textContent = message;
        
        document.body.appendChild(alertDiv);
        
        setTimeout(() => {
            alertDiv.remove();
        }, 5000);
    }

    // Formatear fecha y hora
    formatDateTime(dateTime) {
        const date = new Date(dateTime);
        return date.toLocaleString('es-MX', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    // Formatear fecha para input type="date"
    formatDate(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        
        return `${year}-${month}-${day}`;
    }
    
    // Formatear hora para input type="time"
    formatTime(date) {
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        
        return `${hours}:${minutes}`;
    }
    
    // Combinar fecha y hora en formato ISO
    combineDateTime(dateStr, timeStr) {
        // dateStr viene en formato "YYYY-MM-DD"
        // timeStr viene en formato "HH:MM"
        
        // Crear fecha local para evitar problemas de zona horaria
        const [year, month, day] = dateStr.split('-');
        const [hours, minutes] = timeStr.split(':');
        
        // Crear fecha en zona horaria local
        const localDate = new Date(year, month - 1, day, hours, minutes, 0);
        
        // Convertir a ISO string manteniendo la zona horaria local
        const combined = localDate.toISOString();
        
        console.log('🕐 Fecha y hora combinadas:', combined);
        console.log('📅 Fecha original (local):', localDate.toDateString());
        console.log('📅 Fecha combinada (ISO):', new Date(combined).toDateString());
        
        return combined;
    }
    
    // Formatear fecha y hora para input datetime-local (mantenemos para compatibilidad)
    formatDateTimeLocal(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        
        return `${year}-${month}-${day}T${hours}:${minutes}`;
    }

    // Guardar evento quirúrgico (localmente y en Google Calendar)
    async saveSurgeryEventToFirebase(surgicalEvent) {
        try {
            // Generar ID único si no existe
            if (!surgicalEvent.id) {
                surgicalEvent.id = 'surgery_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
            }
            
            // Agregar timestamps
            surgicalEvent.createdAt = new Date().toISOString();
            surgicalEvent.updatedAt = new Date().toISOString();
            
            // Sincronizar con Google Calendar si está autenticado y no tiene ID de Google Calendar
            if (this.googleCalendarIntegration.isAuthenticated() && !surgicalEvent.googleCalendarEventId) {
                try {
                    console.log('📅 Creando evento en Google Calendar...');
                    const googleEvent = await this.googleCalendarIntegration.createSurgeryEvent(surgicalEvent);
                    surgicalEvent.googleCalendarEventId = googleEvent.id;
                    
                    console.log('✅ Cirugía sincronizada con Google Calendar:', googleEvent.id);
                    console.log('🔗 Enlace del evento:', googleEvent.htmlLink);
                    console.log('🔍 googleCalendarEventId guardado en el evento:', surgicalEvent.googleCalendarEventId);
                    
                    // Verificar que el evento se creó correctamente
                    if (googleEvent.id) {
                        console.log('✅ Evento creado exitosamente en Google Calendar');
                    } else {
                        console.error('❌ Error: El evento no se creó correctamente en Google Calendar');
                    }
                } catch (googleError) {
                    console.error('❌ Error sincronizando con Google Calendar:', googleError);
                    // No fallar si Google Calendar falla, solo logear el error
                }
            } else if (surgicalEvent.googleCalendarEventId) {
                console.log('✅ Cirugía ya tiene ID de Google Calendar, no se duplica');
            } else {
                console.log('⚠️ Usuario no autenticado, solo guardando localmente');
            }
            
            // Guardar en Firebase Realtime Database
            console.log('🔥 Guardando cirugía en Firebase...');
            const database = firebase.database();
            const surgicalEventsRef = database.ref('surgicalEvents');
            
            // Obtener eventos existentes
            const snapshot = await surgicalEventsRef.once('value');
            let surgicalEvents = [];
            
            if (snapshot.exists()) {
                const data = snapshot.val();
                surgicalEvents = Array.isArray(data) ? data : Object.values(data);
            }
            
            // Agregar el nuevo evento
            surgicalEvents.push(surgicalEvent);
            
            // Guardar de vuelta en Firebase
            await surgicalEventsRef.set(surgicalEvents);
            
            console.log('✅ Cirugía guardada en Firebase:', surgicalEvent.id);
            console.log('✅ Total de cirugías en Firebase:', surgicalEvents.length);
            
        } catch (error) {
            console.error('Error guardando cirugía:', error);
            throw error;
        }
    }

    // Actualizar evento quirúrgico (localmente y en Google Calendar)
    async updateSurgeryEventInFirebase(surgicalEvent) {
        try {
            // Actualizar timestamp
            surgicalEvent.updatedAt = new Date().toISOString();
            
            // Sincronizar con Google Calendar si está autenticado
            if (this.googleCalendarIntegration.isAuthenticated() && surgicalEvent.googleCalendarEventId) {
                try {
                    await this.googleCalendarIntegration.updateSurgeryEvent(surgicalEvent);
                    console.log('✅ Cirugía actualizada en Google Calendar:', surgicalEvent.googleCalendarEventId);
                } catch (googleError) {
                    console.error('Error actualizando en Google Calendar:', googleError);
                    // No fallar si Google Calendar falla, solo logear el error
                }
            }
            
            console.log('✅ Cirugía actualizada localmente:', surgicalEvent.id);
            
        } catch (error) {
            console.error('Error actualizando cirugía:', error);
            throw error;
        }
    }

    // Guardar cirugías en localStorage
    saveToLocalStorage() {
        try {
            localStorage.setItem('surgicalEvents', JSON.stringify(this.surgicalEvents));
            console.log('✅ Cirugías guardadas en localStorage');
        } catch (error) {
            console.error('Error guardando en localStorage:', error);
        }
    }

    // Liberar cuarto cuando se elimina una cirugía
    async liberateRoom(roomId, patientName) {
        try {
            console.log('🏠 Liberando cuarto:', roomId, 'para paciente:', patientName);
            
            // Obtener datos de cuartos desde localStorage
            const roomsData = localStorage.getItem('rooms');
            if (!roomsData) {
                console.log('⚠️ No hay datos de cuartos disponibles');
                return;
            }
            
            const rooms = JSON.parse(roomsData);
            const room = rooms.find(r => r.id === roomId);
            
            if (!room) {
                console.log('⚠️ Habitación no encontrada:', roomId);
                return;
            }
            
            // Verificar que el cuarto esté ocupado por el paciente correcto
            if (room.status === 'OCCUPIED' && room.patientName === patientName) {
                // Liberar el cuarto y marcarlo para limpieza
                room.status = 'CLEANING';
                room.patientName = null;
                room.patientDiagnosis = null;
                room.patientDoctor = null;
                room.assignedAt = null;
                room.assignedBy = null;
                room.cleaningRequestedAt = new Date().toISOString();
                room.cleaningRequestedBy = 'Sistema Automático';
                room.updatedAt = new Date().toISOString();
                
                // Guardar cuartos actualizados
                localStorage.setItem('rooms', JSON.stringify(rooms));
                
                console.log('✅ Cuarto liberado y marcado para limpieza:', {
                    room: room.number,
                    previousPatient: patientName,
                    newStatus: room.status,
                    cleaningRequestedAt: room.cleaningRequestedAt
                });
                
                // Mostrar mensaje informativo
                this.showAlert(`🧹 Cuarto ${room.number} liberado y marcado para limpieza`, 'info');
                
            } else {
                console.log('⚠️ El cuarto no está ocupado por este paciente o ya está disponible');
            }
            
        } catch (error) {
            console.error('❌ Error al liberar cuarto:', error);
            this.showAlert('⚠️ Error al liberar cuarto, pero la cirugía se eliminó correctamente', 'warning');
        }
    }

    // Guardar cirugías en Firebase
    async saveSurgicalEventsToFirebase() {
        try {
            console.log('🔥 Guardando cirugías en Firebase...');
            
            // Verificar que Firebase esté disponible
            if (typeof firebase === 'undefined') {
                console.log('⚠️ Firebase no está disponible, solo guardando localmente');
                return;
            }
            
            // Obtener referencia a la base de datos
            const database = firebase.database();
            
            // Esperar a que el usuario esté autenticado
            const currentUser = firebase.auth().currentUser;
            if (!currentUser) {
                console.log('⏳ Usuario no autenticado, esperando autenticación...');
                
                // Esperar a que el usuario se autentique
                return new Promise((resolve, reject) => {
                    const unsubscribe = firebase.auth().onAuthStateChanged((user) => {
                        unsubscribe();
                        if (user) {
                            console.log('✅ Usuario autenticado, continuando con el guardado...');
                            this.saveSurgicalEventsToFirebase().then(resolve).catch(reject);
                        } else {
                            console.log('❌ Usuario no se pudo autenticar');
                            reject(new Error('Usuario no autenticado'));
                        }
                    });
                });
            }
            
            console.log('🔥 Usuario autenticado:', currentUser.uid);
            
            // Guardar en la ruta global
            const surgicalEventsRef = database.ref('surgicalEvents');
            
            console.log('🔥 Guardando cirugías en Firebase...');
            
            // Guardar todas las cirugías
            await surgicalEventsRef.set(this.surgicalEvents);
            
            console.log('✅ Cirugías guardadas en Firebase exitosamente');
            
        } catch (error) {
            console.error('❌ Error al guardar cirugías en Firebase:', error);
            throw error;
        }
    }

    // Eliminar paciente pendiente de Firebase por surgeryId
    async deletePendingPatientBySurgeryId(surgeryId) {
        try {
            console.log('👤 INICIO: deletePendingPatientBySurgeryId llamada con surgeryId:', surgeryId);
            
            // Verificar que Firebase esté configurado
            if (!firebase || !firebase.database) {
                console.error('❌ Firebase no está configurado');
                return;
            }

            console.log('🔥 Firebase configurado correctamente');
            const database = firebase.database();
            const pendingPatientsRef = database.ref('pendingPatients');
            console.log('🔥 Referencia a pendingPatients obtenida');
            
            // Buscar el paciente por surgeryId
            console.log('🔍 Obteniendo snapshot de pendingPatients...');
            const snapshot = await pendingPatientsRef.once('value');
            console.log('🔍 Snapshot obtenido, existe:', snapshot.exists());
            
            if (snapshot.exists()) {
                const patientsData = snapshot.val();
                console.log('📊 Total de pacientes en Firebase:', Object.keys(patientsData).length);
                console.log('📊 Primeros 3 pacientes:', Object.values(patientsData).slice(0, 3));
                
                let patientToDelete = null;
                let patientKey = null;
                
                // Buscar el paciente por surgeryId
                console.log('🔍 Buscando paciente con surgeryId:', surgeryId);
                for (const [key, patient] of Object.entries(patientsData)) {
                    console.log('🔍 Verificando paciente:', key, 'surgeryId:', patient.surgeryId);
                    if (patient.surgeryId === surgeryId) {
                        patientToDelete = patient;
                        patientKey = key;
                        console.log('✅ Paciente encontrado!');
                        break;
                    }
                }
                
                if (patientToDelete && patientKey) {
                    console.log('🔍 Paciente encontrado para eliminar:', patientToDelete.name);
                    console.log('🔍 SurgeryId del paciente:', patientToDelete.surgeryId);
                    console.log('🔍 Key del paciente:', patientKey);
                    
                    // Eliminar el paciente específico
                    console.log('🗑️ Eliminando paciente de Firebase...');
                    const patientRef = pendingPatientsRef.child(patientKey);
                    await patientRef.remove();
                    
                    console.log('✅ Paciente pendiente eliminado de Firebase:', patientToDelete.name);
                } else {
                    console.log('⚠️ Paciente pendiente no encontrado en Firebase para surgeryId:', surgeryId);
                    console.log('⚠️ Todos los surgeryIds encontrados:', Object.values(patientsData).map(p => p.surgeryId));
                }
            } else {
                console.log('⚠️ No hay pacientes pendientes en Firebase');
            }
            
            console.log('👤 FIN: deletePendingPatientBySurgeryId completada');
            
        } catch (error) {
            console.error('❌ Error al eliminar paciente pendiente de Firebase:', error);
            console.error('❌ Stack trace:', error.stack);
            // No lanzar el error para no interrumpir la eliminación de la cirugía
        }
    }

    // Eliminar paciente pendiente de Firebase por patientId (mantener para compatibilidad)
    async deletePendingPatient(patientId) {
        try {
            console.log('👤 Eliminando paciente pendiente de Firebase:', patientId);
            
            // Verificar que Firebase esté configurado
            if (!firebase || !firebase.database) {
                console.error('❌ Firebase no está configurado');
                return;
            }

            const database = firebase.database();
            const pendingPatientsRef = database.ref('pendingPatients');
            
            // Buscar el paciente por ID
            const snapshot = await pendingPatientsRef.once('value');
            if (snapshot.exists()) {
                const patientsData = snapshot.val();
                let patientToDelete = null;
                let patientKey = null;
                
                // Buscar el paciente por ID
                for (const [key, patient] of Object.entries(patientsData)) {
                    if (patient.id === patientId) {
                        patientToDelete = patient;
                        patientKey = key;
                        break;
                    }
                }
                
                if (patientToDelete && patientKey) {
                    console.log('🔍 Paciente encontrado para eliminar:', patientToDelete.name);
                    
                    // Eliminar el paciente específico
                    const patientRef = pendingPatientsRef.child(patientKey);
                    await patientRef.remove();
                    
                    console.log('✅ Paciente pendiente eliminado de Firebase:', patientToDelete.name);
                } else {
                    console.log('⚠️ Paciente pendiente no encontrado en Firebase:', patientId);
                }
            } else {
                console.log('⚠️ No hay pacientes pendientes en Firebase');
            }
            
        } catch (error) {
            console.error('❌ Error al eliminar paciente pendiente de Firebase:', error);
            // No lanzar el error para no interrumpir la eliminación de la cirugía
        }
    }
}

// Funciones globales para el HTML
function showCreateSurgeryModal() {
    window.surgicalApp.showCreateSurgeryModal();
}

function clearLocalData() {
    if (confirm('¿Estás seguro de que quieres limpiar todos los datos locales? Esto forzará una sincronización completa con Google Calendar.')) {
        // Limpiar localStorage
        localStorage.removeItem('surgicalEvents');
        
        // Limpiar array local
        window.surgicalApp.surgicalEvents = [];
        
        // Actualizar interfaz
        window.surgicalApp.updateCalendar();
        window.surgicalApp.updateSurgeryList();
        
        // Mostrar mensaje
        window.surgicalApp.showAlert('Datos locales limpiados. Haz clic en "Sincronizar" para cargar desde Google Calendar.', 'info');
        
        console.log('🗑️ Datos locales limpiados');
    }
}

function closeSurgeryModal() {
    window.surgicalApp.closeSurgeryModal();
}

function syncWithGoogleCalendar() {
    window.surgicalApp.syncWithGoogleCalendar();
}

function exportSchedule() {
    window.surgicalApp.exportSchedule();
}

// Inicializar aplicación cuando se carga la página
document.addEventListener('DOMContentLoaded', () => {
    window.surgicalApp = new SurgicalSchedulingApp();
});

// Función global para exportar pacientes pendientes
function exportPendingPatients() {
    console.log('🔄 Función exportPendingPatients llamada');
    console.log('🔍 window.surgicalApp:', window.surgicalApp);
    
    if (window.surgicalApp) {
        console.log('✅ Aplicación encontrada, llamando método...');
        window.surgicalApp.exportPendingPatients();
    } else {
        console.error('❌ Aplicación quirúrgica no inicializada');
        alert('❌ Error: Aplicación no inicializada. Recarga la página.');
    }
}
