# 🔥 Configuración de Firebase para la Aplicación Web

## 📋 Pasos para configurar Firebase en la página web

### 1. **Obtener la configuración de Firebase**

1. Ve a [Firebase Console](https://console.firebase.google.com/)
2. Selecciona tu proyecto **CMQ San José**
3. Ve a **Project Settings** (⚙️) > **General**
4. En la sección **Your apps**, busca la app web o crea una nueva:
   - Haz clic en **Add app** > **Web** (</>)
   - Dale un nombre como "CMQ San José Web"
   - **NO** marques "Set up Firebase Hosting" por ahora
   - Haz clic en **Register app**

### 2. **Copiar la configuración**

Firebase te mostrará un código como este:

```javascript
const firebaseConfig = {
  apiKey: "AIzaSyC...",
  authDomain: "cmq-sanjos.firebaseapp.com",
  projectId: "cmq-sanjos",
  storageBucket: "cmq-sanjos.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef..."
};
```

### 3. **Actualizar el archivo de configuración**

1. Abre el archivo `web/firebase-config.js`
2. Reemplaza la configuración placeholder con tu configuración real:

```javascript
const firebaseConfig = {
    apiKey: "AIzaSyC...", // Tu API key real
    authDomain: "cmq-sanjos.firebaseapp.com", // Tu dominio real
    projectId: "cmq-sanjos", // Tu project ID real
    storageBucket: "cmq-sanjos.appspot.com", // Tu storage bucket real
    messagingSenderId: "123456789", // Tu sender ID real
    appId: "1:123456789:web:abcdef..." // Tu app ID real
};
```

### 4. **Configurar reglas de Firestore**

Asegúrate de que las reglas de Firestore permitan lectura/escritura para usuarios autenticados:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

### 5. **Probar la aplicación**

1. Abre `web/index.html` en tu navegador
2. Intenta crear una nueva cuenta
3. Verifica en Firebase Console > Authentication que el usuario se creó
4. Verifica en Firebase Console > Firestore que se guardó en la colección `users`

## 🔧 Solución de problemas

### Error: "Firebase SDK no está cargado"
- Verifica que los scripts de Firebase estén cargando correctamente
- Revisa la consola del navegador para errores de red

### Error: "No se pudo inicializar Firebase"
- Verifica que la configuración en `firebase-config.js` sea correcta
- Asegúrate de que el projectId coincida con tu proyecto

### Error: "Permission denied"
- Verifica las reglas de Firestore
- Asegúrate de que el usuario esté autenticado

### Los usuarios no se guardan en Firestore
- Verifica que las reglas de Firestore permitan escritura
- Revisa la consola del navegador para errores
- Asegúrate de que el usuario esté autenticado antes de escribir

## 📱 Funcionalidades implementadas

✅ **Autenticación completa con Firebase**
- Login con email/contraseña
- Registro de nuevos usuarios
- Logout seguro
- Persistencia de sesión

✅ **Integración con Firestore**
- Guardar datos de usuario al registrarse
- Obtener datos de usuario al hacer login
- Sincronización automática con la app Android

✅ **Manejo de errores**
- Mensajes de error en español
- Validación de formularios
- Estados de carga

## 🚀 Próximos pasos

Una vez configurado Firebase, podrás:
1. Crear usuarios desde la web y verlos en la app Android
2. Hacer login desde cualquier dispositivo
3. Sincronizar datos entre web y móvil
4. Implementar más funcionalidades (pacientes, cuartos, etc.)

