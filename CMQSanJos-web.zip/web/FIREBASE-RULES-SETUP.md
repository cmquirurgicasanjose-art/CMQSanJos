# 🔥 Configuración de Reglas de Firebase

## 📋 Pasos para Aplicar las Reglas de Seguridad

### **Opción 1: Usando Firebase CLI (Recomendado)**

1. **Instalar Firebase CLI** (si no está instalado):
   ```bash
   npm install -g firebase-tools
   ```

2. **Iniciar sesión en Firebase**:
   ```bash
   firebase login
   ```

3. **Aplicar las reglas**:
   ```bash
   firebase deploy --only database
   ```

### **Opción 2: Usando el Script Automático**

1. **Ejecutar el script**:
   ```bash
   .\apply-firebase-rules.bat
   ```

### **Opción 3: Manualmente desde Firebase Console**

1. **Ir a Firebase Console**: https://console.firebase.google.com/
2. **Seleccionar tu proyecto**: `cmqsanjos-clinica`
3. **Ir a Realtime Database** → **Reglas**
4. **Reemplazar las reglas existentes** con:

```json
{
  "rules": {
    "users": {
      "$uid": {
        ".read": "$uid === auth.uid",
        ".write": "$uid === auth.uid"
      }
    },
    "clinic_rooms": {
      ".read": "auth != null",
      ".write": "auth != null"
    },
    "pendingPatients": {
      ".read": "auth != null",
      ".write": "auth != null"
    },
    "surgicalEvents": {
      ".read": "auth != null",
      ".write": "auth != null"
    }
  }
}
```

5. **Hacer clic en "Publicar"**

## ✅ Reglas Configuradas

- **`/pendingPatients`**: Lectura/escritura para usuarios autenticados
- **`/clinic_rooms`**: Lectura/escritura para usuarios autenticados  
- **`/surgicalEvents`**: Lectura/escritura para usuarios autenticados
- **`/users/{uid}`**: Solo el usuario propietario puede leer/escribir

## 🧪 Verificar que Funciona

1. **Crear una cirugía** en Programación Quirúrgica
2. **Verificar** que aparece en Gestión de Pacientes
3. **Revisar** la consola para confirmar que no hay errores de permisos

## 🔧 Solución de Problemas

Si sigues viendo errores de permisos:

1. **Verificar** que las reglas se aplicaron correctamente
2. **Revisar** que el usuario esté autenticado
3. **Comprobar** que el proyecto Firebase es correcto

