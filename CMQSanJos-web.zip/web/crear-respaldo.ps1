# Script de Respaldo Automático - CMQ San José
# Fecha: 12 de Septiembre de 2025

Write-Host "🏥 CMQ San José - Creando Respaldo Completo..." -ForegroundColor Green

# Crear carpeta de respaldo con fecha y hora
$fecha = Get-Date -Format "yyyy-MM-dd-HHmm"
$carpetaRespaldo = "CMQSanJos-RESPALDO-$fecha"

Write-Host "📁 Creando carpeta: $carpetaRespaldo" -ForegroundColor Yellow

# Crear la carpeta de respaldo
New-Item -ItemType Directory -Path "..\$carpetaRespaldo" -Force | Out-Null

# Copiar todos los archivos importantes
Write-Host "📋 Copiando archivos del sistema..." -ForegroundColor Yellow

# Archivos principales
$archivos = @(
    "index-hybrid-realtime.html",
    "surgical-scheduling-ui.html", 
    "surgical-scheduling-app.js",
    "google-calendar-integration.js",
    "google-calendar-config.js",
    "firebase-config-realtime.js",
    "firebase-rules.json",
    "auth-system.js",
    "surgical-specialties.js",
    "surgical-event-model.js",
    "RESPALDO-COMPLETO.md"
)

foreach ($archivo in $archivos) {
    if (Test-Path $archivo) {
        Copy-Item $archivo "..\$carpetaRespaldo\" -Force
        Write-Host "✅ Copiado: $archivo" -ForegroundColor Green
    } else {
        Write-Host "⚠️ No encontrado: $archivo" -ForegroundColor Red
    }
}

# Crear archivo de información del respaldo
$infoRespaldo = @"
# 🏥 CMQ San José - Información del Respaldo
**Fecha de Respaldo:** $(Get-Date -Format "dd/MM/yyyy HH:mm:ss")
**Versión:** 1.0 - Sistema Funcional Completo

## 📋 Archivos Incluidos en este Respaldo:
- index-hybrid-realtime.html (Dashboard principal)
- surgical-scheduling-ui.html (Interfaz de programación)
- surgical-scheduling-app.js (Lógica de programación)
- google-calendar-integration.js (Integración con Google Calendar)
- google-calendar-config.js (Configuración de Google Calendar)
- firebase-config-realtime.js (Configuración de Firebase)
- firebase-rules.json (Reglas de seguridad)
- auth-system.js (Sistema de autenticación)
- surgical-specialties.js (Especialidades médicas)
- surgical-event-model.js (Modelo de eventos quirúrgicos)
- RESPALDO-COMPLETO.md (Documentación completa)

## 🚀 Estado del Sistema:
✅ Sistema de autenticación completo
✅ Gestión de pacientes funcional
✅ Sistema de cuartos operativo
✅ Programación quirúrgica integrada
✅ Google Calendar sincronizado
✅ Días de estancia automáticos
✅ Modales de edición mejorados

## 📝 Notas:
- Este respaldo contiene todas las funcionalidades implementadas
- El sistema está listo para producción
- Todas las integraciones funcionan correctamente
- Código optimizado y sin errores

¡Sistema CMQ San José completamente funcional! 🎉
"@

$infoRespaldo | Out-File -FilePath "..\$carpetaRespaldo\INFORMACION-RESPALDO.md" -Encoding UTF8

Write-Host "📄 Archivo de información creado" -ForegroundColor Green

# Mostrar resumen
Write-Host "`n🎉 ¡Respaldo completado exitosamente!" -ForegroundColor Green
Write-Host "📁 Carpeta de respaldo: ..\$carpetaRespaldo" -ForegroundColor Cyan
Write-Host "📋 Archivos respaldados: $($archivos.Count)" -ForegroundColor Cyan
Write-Host "`n💡 Para restaurar el sistema, copia los archivos de la carpeta de respaldo de vuelta a la carpeta web/" -ForegroundColor Yellow

# Abrir la carpeta de respaldo
Write-Host "`n🔍 Abriendo carpeta de respaldo..." -ForegroundColor Yellow
Start-Process "..\$carpetaRespaldo"
